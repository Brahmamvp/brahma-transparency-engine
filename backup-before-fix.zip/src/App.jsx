import React from 'react';
import TransparencyEngine from './components/transparency/TransparencyEngine.jsx';

// Keep this tiny user object so Avatar/Header have data
const demoUser = {
  name: 'You',
  sage: {
    name: 'Sage',
    form: 'orb',
    emotion: 'calm',
  },
};

export default function App() {
  return (
    <div className="min-h-screen">
      <TransparencyEngine userData={demoUser} />
    </div>
  );
}