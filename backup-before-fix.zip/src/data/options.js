// /src/data/options.js
export const optionTemplates = {
  education: [
    {
      title: 'UX Design Bootcamp',
      cost: '$12,000 / 6 months',
      risk: 'Medium',
      summary: 'Intensive skill-building with career support',
      details: {
        timeCommitment: '40 hours/week',
        successRate: '78% job placement within 6 months',
        considerations: 'Requires significant time investment during program',
        alignmentFactors: ['career change', 'creative work', 'structured learning']
      }
    },
    {
      title: 'Online Computer Science Degree',
      cost: '$15,000 / 2 years',
      risk: 'Low',
      summary: 'Comprehensive foundation with flexible timeline',
      details: {
        timeCommitment: '15-20 hours/week',
        successRate: '85% completion rate',
        considerations: 'Longer timeline but more flexible schedule',
        alignmentFactors: ['structured learning', 'long-term growth', 'flexibility']
      }
    },
    {
      title: 'Self-Directed Learning Path',
      cost: '$500-2000 / ongoing',
      risk: 'Medium',
      summary: 'Maximum flexibility with curated resources',
      details: {
        timeCommitment: 'Self-determined',
        successRate: '60% reach initial goals within 1 year',
        considerations: 'Requires strong self-motivation and structure',
        alignmentFactors: ['autonomy', 'budget-conscious', 'experimental']
      }
    }
  ],
  business: [
    {
      title: 'Start a Consulting Practice',
      cost: '$2,000 startup / variable income',
      risk: 'High',
      summary: 'Leverage existing expertise with entrepreneurial freedom',
      details: {
        timeCommitment: 'Full-time equivalent',
        successRate: '65% achieve sustainable income within 1 year',
        considerations: 'Income uncertainty in first 6-12 months',
        alignmentFactors: ['autonomy', 'expertise leverage', 'income potential']
      }
    },
    {
      title: 'Side Project While Employed',
      cost: '$500 / evenings & weekends',
      risk: 'Low',
      summary: 'Test entrepreneurial waters while maintaining stability',
      details: {
        timeCommitment: '10-15 hours/week',
        successRate: '45% develop into viable businesses',
        considerations: 'Limited time and energy management challenges',
        alignmentFactors: ['security', 'experimentation', 'gradual transition']
      }
    }
  ]
};

// /src/data/stories.js
export const storyBlocks = [
  {
    demographic: 'moderate_flexible',
    story: 'I started the bootcamp scared but excited. The structure helped, and having a cohort made all the difference.',
    outcome: 'Now a senior UX designer at a tech startup',
    timeframe: '8 months total'
  },
  {
    demographic: 'conservative_longterm',
    story: 'The degree felt safer because I could keep working. It took longer, but I never felt overwhelmed.',
    outcome: 'Transitioned to tech lead role at current company',
    timeframe: '2.5 years'
  },
  {
    demographic: 'adventurous_immediate',
    story: 'I jumped into consulting with just savings and confidence. The first year was tough but taught me everything.',
    outcome: 'Built a 6-figure practice within 18 months',
    timeframe: '18 months'
  },
  {
    demographic: 'moderate_immediate',
    story: 'The side project approach let me test ideas without burning bridges. When it took off, the transition felt natural.',
    outcome: 'Launched profitable SaaS while keeping day job initially',
    timeframe: '14 months'
  },
  {
    demographic: 'conservative_flexible',
    story: 'Online learning gave me control over pace. I could pause during busy family times and accelerate when free.',
    outcome: 'Completed certification and got promoted internally',
    timeframe: '18 months'
  }
];

export const wisdomPatterns = {
  education: {
    bootcamp: "68% of people with similar timelines found the peer support crucial to completion",
    degree: "Most flexible learners appreciated being able to slow down during life events",
    selfDirected: "Success correlates strongly with having an accountability system"
  },
  business: {
    consulting: "People who started with 3+ months expenses saved felt more confident in year one",
    sideProject: "Those who validated their idea with 10+ potential customers had higher success rates"
  }
};
