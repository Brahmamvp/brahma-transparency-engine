export const getOnboardingStatus = () => {
  return localStorage.getItem('onboardingComplete') === 'true';
};

export const saveSageData = (data) => {
  localStorage.setItem('brahma_sage', JSON.stringify(data));
};

export const saveUserProfile = (data) => {
  localStorage.setItem('brahma_user_profile', JSON.stringify(data));
  localStorage.setItem('onboardingComplete', 'true');
};

export const getUserData = () => {
  try {
    const sageData = JSON.parse(localStorage.getItem('brahma_sage'));
    const profileData = JSON.parse(localStorage.getItem('brahma_user_profile'));
    return { sage: sageData, profile: profileData };
  } catch (error) {
    console.error("Failed to parse user data from localStorage", error);
    return { sage: null, profile: null };
  }
};
