// Minimal helpers to keep components clean

export const exportJSON = (filename, data) => {
  try {
    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  } catch (e) {
    console.error("Export JSON failed:", e);
  }
};

export const exportMarkdown = (filename, markdownString) => {
  try {
    const blob = new Blob([markdownString], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  } catch (e) {
    console.error("Export MD failed:", e);
  }
};
