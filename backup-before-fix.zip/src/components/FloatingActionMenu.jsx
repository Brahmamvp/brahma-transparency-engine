// /src/components/FloatingActionMenu.jsx
import React from 'react';

export default function FloatingActionMenu({ onExport }) {
  const handleExport = () => {
    // Export functionality - would generate a summary document
    const exportData = {
      timestamp: new Date().toISOString(),
      insights: "This exploration session focused on career transition options with moderate risk tolerance.",
      // Add more export data here
    };
    onExport(exportData);
  };

  return (
    <div className="fixed bottom-6 right-6 flex flex-col gap-2 z-40">
      <button
        onClick={handleExport}
        className="glassmorphism p-3 rounded-full shadow-lg hover:shadow-xl transition-shadow group"
        title="Export your exploration summary"
      >
        <svg className="w-5 h-5 text-gray-600 group-hover:text-purple-600 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
      </button>
      
      <button
        className="glassmorphism p-3 rounded-full shadow-lg hover:shadow-xl transition-shadow group opacity-50"
        title="Legacy Echo - Coming Soon"
        disabled
      >
        <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>
      </button>
    </div>
  );
}
