// src/components/transparency/SettingsPanel.jsx
import React, { useEffect, useState } from "react";
import {
  X,
  Sliders,
  Eye,
  Accessibility,
  Shield,
  Gauge,
  Cpu,
  Database,
  Sparkles,
  Zap,
  FolderOpen,
} from "lucide-react";

const TABS = [
  { key: "general", label: "General", icon: Sliders },
  { key: "display", label: "Display", icon: Eye },
  { key: "access", label: "Accessibility", icon: Accessibility },
  { key: "integrations", label: "Integrations", icon: FolderOpen },
  { key: "advanced", label: "Advanced", icon: Gauge },
];

const SettingsPanel = ({
  onClose,
  userData,
  onSettingsChange,
  onOpenMemorySettings,   // optional
  onOpenVoiceModulator,   // optional
  onOpenSoulTimeline,     // optional
}) => {
  const [activeTab, setActiveTab] = useState("general");
  const [localSettings, setLocalSettings] = useState({
    showParticles:
      (localStorage.getItem("brahma_show_particles") ?? "true") !== "false",
    showAvatar:
      (localStorage.getItem("brahma_show_avatar") ?? "true") !== "false",
    reducedMotion:
      (localStorage.getItem("brahma_reduced_motion") ?? "false") === "true",
    compactMode:
      (localStorage.getItem("brahma_compact_mode") ?? "false") === "true",
    highContrast:
      (localStorage.getItem("brahma_high_contrast") ?? "false") === "true",
    fontScale: Number(localStorage.getItem("brahma_font_scale") ?? 100), // %
  });

  useEffect(() => {
    // keep localStorage in sync when local settings change inside panel
    try {
      localStorage.setItem(
        "brahma_show_particles",
        localSettings.showParticles ? "true" : "false"
      );
      localStorage.setItem(
        "brahma_show_avatar",
        localSettings.showAvatar ? "true" : "false"
      );
      localStorage.setItem(
        "brahma_reduced_motion",
        localSettings.reducedMotion ? "true" : "false"
      );
      localStorage.setItem(
        "brahma_compact_mode",
        localSettings.compactMode ? "true" : "false"
      );
      localStorage.setItem(
        "brahma_high_contrast",
        localSettings.highContrast ? "true" : "false"
      );
      localStorage.setItem(
        "brahma_font_scale",
        String(Math.max(80, Math.min(140, localSettings.fontScale)))
      );
    } catch {}
  }, [localSettings]);

  const toggle = (key) => {
    setLocalSettings((p) => {
      const next = { ...p, [key]: !p[key] };
      // bubble up for engine-level layout changes if parent wants it
      if (onSettingsChange) onSettingsChange(key, next[key]);
      return next;
    });
  };

  const setNumber = (key, value) => {
    const v = Number(value);
    setLocalSettings((p) => {
      const next = { ...p, [key]: v };
      if (onSettingsChange) onSettingsChange(key, v);
      return next;
    });
  };

  const openMemorySettings = () => {
    if (onOpenMemorySettings) return onOpenMemorySettings();
    window.dispatchEvent(new CustomEvent("brahma-open-memory-settings"));
  };
  const openVoiceModulator = () => {
    if (onOpenVoiceModulator) return onOpenVoiceModulator();
    window.dispatchEvent(new CustomEvent("brahma-open-voice-modulator"));
  };
  const openSoulTimeline = () => {
    if (onOpenSoulTimeline) return onOpenSoulTimeline();
    window.dispatchEvent(new CustomEvent("brahma-open-soul-timeline"));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      />
      {/* Panel */}
      <div className="relative bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl shadow-2xl w-full max-w-5xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-white/10 bg-gradient-to-r from-purple-600/20 to-pink-600/20">
          <div>
            <h2 className="text-xl font-semibold text-white">Settings</h2>
            <p className="text-xs text-purple-200/80 mt-1">
              Personalize Sage and your workspace. All preferences save locally.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-white/10 text-gray-300"
            aria-label="Close settings"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex">
          {/* Tabs (left) */}
          <aside className="hidden sm:block w-48 border-r border-white/10 p-3">
            <nav className="space-y-1">
              {TABS.map(({ key, label, icon: Icon }) => (
                <button
                  key={key}
                  onClick={() => setActiveTab(key)}
                  className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition ${
                    activeTab === key
                      ? "bg-white/15 text-white"
                      : "text-purple-200 hover:bg-white/10"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {label}
                </button>
              ))}
            </nav>

            <div className="mt-6 pt-4 border-t border-white/10 space-y-2">
              {/* Fast access to wisdom/rl/voice/timeline */}
              <QuickOpen
                icon={<Sparkles className="w-4 h-4" />}
                label="Memory Settings"
                onClick={openMemorySettings}
              />
              <QuickOpen
                icon={<Zap className="w-4 h-4" />}
                label="Voice Modulator"
                onClick={openVoiceModulator}
              />
              <QuickOpen
                icon={<Cpu className="w-4 h-4" />}
                label="Soul Timeline"
                onClick={openSoulTimeline}
              />
            </div>
          </aside>

          {/* Body (right) */}
          <main className="flex-1 p-6 overflow-y-auto">
            {activeTab === "general" && (
              <Section title="General">
                <ToggleRow
                  label="Show Particles"
                  description="Animated background particles for a touch of magic."
                  value={localSettings.showParticles}
                  onChange={() => toggle("showParticles")}
                />
                <ToggleRow
                  label="Show Floating Avatar"
                  description="Keep Sage present in the corner while you work."
                  value={localSettings.showAvatar}
                  onChange={() => toggle("showAvatar")}
                />
                <ToggleRow
                  label="Compact Mode"
                  description="Tighter spacing in lists and panels."
                  value={localSettings.compactMode}
                  onChange={() => toggle("compactMode")}
                />

                <div className="mt-6 grid sm:grid-cols-2 gap-4">
                  <SliderRow
                    label="Interface Font Scale"
                    description="Adjust UI text size across panels."
                    value={localSettings.fontScale}
                    min={80}
                    max={140}
                    step={5}
                    unit="%"
                    onChange={(v) => setNumber("fontScale", v)}
                  />
                </div>

                <div className="mt-8 bg-white/5 border border-white/10 rounded-xl p-4">
                  <h4 className="text-sm font-semibold text-white mb-2">
                    Memory & Voice Shortcuts
                  </h4>
                  <div className="grid sm:grid-cols-3 gap-3">
                    <ActionButton onClick={openMemorySettings} icon={<Database className="w-4 h-4" />}>
                      Open Memory Settings
                    </ActionButton>
                    <ActionButton onClick={openVoiceModulator} icon={<Zap className="w-4 h-4" />}>
                      Open Voice Modulator
                    </ActionButton>
                    <ActionButton onClick={openSoulTimeline} icon={<Cpu className="w-4 h-4" />}>
                      Open Soul Timeline
                    </ActionButton>
                  </div>
                </div>
              </Section>
            )}

            {activeTab === "display" && (
              <Section title="Display">
                <ToggleRow
                  label="Reduce Motion"
                  description="Minimize animations for focus and accessibility."
                  value={localSettings.reducedMotion}
                  onChange={() => toggle("reducedMotion")}
                />
                <ToggleRow
                  label="High Contrast"
                  description="Boost contrast for improved readability."
                  value={localSettings.highContrast}
                  onChange={() => toggle("highContrast")}
                />
                <div className="mt-4 text-xs text-purple-200/70">
                  Tip: You can also use browser zoom (⌘/Ctrl + “+” or “-”).
                </div>
              </Section>
            )}

            {activeTab === "access" && (
              <Section title="Accessibility">
                <p className="text-sm text-gray-300">
                  Brahma aims to support a calm, readable interface. If you
                  need additional accommodations, let us know what would help.
                </p>
                <ul className="mt-4 text-sm text-gray-300 list-disc pl-5 space-y-2">
                  <li>Keyboard navigation for modals and tabs</li>
                  <li>ARIA labels on actionable elements</li>
                  <li>Optional subtitles in voice experiences</li>
                </ul>
              </Section>
            )}

            {activeTab === "integrations" && (
              <Section title="Integrations">
                <p className="text-sm text-gray-300 mb-3">
                  Local-first by default. Future opt-in connectors will appear
                  here with clear scopes and consent gates.
                </p>
                <div className="grid sm:grid-cols-2 gap-3">
                  <IntegrationCard
                    name="Calendar (read-only)"
                    status="Coming soon"
                  />
                  <IntegrationCard
                    name="Docs (local parsing)"
                    status="Coming soon"
                  />
                </div>
              </Section>
            )}

            {activeTab === "advanced" && (
              <Section title="Advanced & Privacy">
                <div className="grid sm:grid-cols-2 gap-4">
                  <Tile
                    icon={<Shield className="w-5 h-5 text-emerald-400" />}
                    title="Privacy Contract"
                    desc="Review or activate your Lifetime Privacy agreement."
                    actionLabel="Open"
                    onClick={() =>
                      window.dispatchEvent(
                        new CustomEvent("brahma-open-privacy")
                      )
                    }
                  />
                  <Tile
                    icon={<Database className="w-5 h-5 text-blue-300" />}
                    title="Data Shadow"
                    desc="See and manage your latent profile."
                    actionLabel="Open"
                    onClick={() =>
                      window.dispatchEvent(
                        new CustomEvent("brahma-open-data-shadow")
                      )
                    }
                  />
                </div>

                <div className="mt-6 text-xs text-purple-300 italic">
                  Governed by the Wisdom Integration Layer • RL signals logged locally • You own your evolution
                </div>
              </Section>
            )}
          </main>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-white/10 flex items-center justify-between">
          <div className="text-xs text-purple-200/70">
            Changes save automatically to your device.
          </div>
          <button
            onClick={onClose}
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-5 py-2 rounded-xl text-sm font-medium transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

/* ===== tiny presentational helpers ===== */

function Section({ title, children }) {
  return (
    <section className="mb-8">
      <h3 className="text-white font-semibold mb-3">{title}</h3>
      <div className="space-y-4">{children}</div>
    </section>
  );
}

function ToggleRow({ label, description, value, onChange }) {
  return (
    <div className="flex items-center justify-between gap-4 bg-white/5 p-3 rounded-lg border border-white/10">
      <div>
        <div className="text-sm text-white">{label}</div>
        {description && (
          <div className="text-xs text-gray-400">{description}</div>
        )}
      </div>
      <label className="relative inline-flex items-center cursor-pointer">
        <input
          type="checkbox"
          className="sr-only peer"
          checked={value}
          onChange={onChange}
        />
        <div className="w-10 h-5 bg-gray-600 rounded-full peer peer-checked:bg-purple-600 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:h-4 after:w-4 after:rounded-full after:transition-all peer-checked:after:translate-x-5" />
      </label>
    </div>
  );
}

function SliderRow({ label, description, value, min, max, step, unit, onChange }) {
  return (
    <div className="bg-white/5 p-4 rounded-lg border border-white/10">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-sm text-white">{label}</div>
          {description && (
            <div className="text-xs text-gray-400">{description}</div>
          )}
        </div>
        <div className="text-xs text-gray-300 font-mono">
          {value}
          {unit}
        </div>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full mt-3 accent-purple-500"
      />
    </div>
  );
}

function Tile({ icon, title, desc, actionLabel, onClick }) {
  return (
    <div className="bg-white/5 p-4 rounded-xl border border-white/10 flex items-start justify-between">
      <div className="flex items-start gap-3">
        <div className="shrink-0">{icon}</div>
        <div>
          <div className="text-sm text-white font-medium">{title}</div>
          <div className="text-xs text-gray-400">{desc}</div>
        </div>
      </div>
      <button
        onClick={onClick}
        className="px-3 py-1.5 text-xs rounded-lg bg-white/10 hover:bg-white/20 border border-white/20"
      >
        {actionLabel}
      </button>
    </div>
  );
}

function IntegrationCard({ name, status }) {
  return (
    <div className="bg-white/5 p-4 rounded-xl border border-white/10">
      <div className="flex items-center justify-between">
        <div className="text-sm text-white">{name}</div>
        <div className="text-xs px-2 py-1 rounded-full bg-gray-500/20 text-gray-300">
          {status}
        </div>
      </div>
      <div className="text-xs text-gray-400 mt-2">
        Local-first; explicit consent required for any connector.
      </div>
    </div>
  );
}

function ActionButton({ icon, children, onClick }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 px-3 py-2 rounded-lg text-xs transition"
    >
      {icon}
      {children}
    </button>
  );
}

function QuickOpen({ icon, label, onClick }) {
  return (
    <button
      onClick={onClick}
      className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-left text-xs bg-white/5 hover:bg-white/10 text-purple-200"
    >
      {icon}
      {label}
    </button>
  );
}

export default SettingsPanel;
