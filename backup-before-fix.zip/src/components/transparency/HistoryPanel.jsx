// src/components/transparency/HistoryPanel.jsx
import React, { useEffect, useMemo, useState } from "react";

/** Local storage key */
const LS_KEY = "brahma_chat_history_v1";

/** Convert array of chats to CSV */
function toCSV(rows) {
  if (!rows?.length) return "";
  const cols = ["id", "title", "project", "tags", "createdAt", "updatedAt", "messageCount"];
  const esc = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const head = cols.join(",");
  const body = rows
    .map((r) =>
      [
        r.id,
        r.title,
        r.project || "",
        (r.tags || []).join("|"),
        r.createdAt,
        r.updatedAt || "",
        r.messages?.length ?? 0,
      ]
        .map(esc)
        .join(",")
    )
    .join("\n");
  return `${head}\n${body}`;
}

function download(filename, text, mime = "text/plain") {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

/** One chat record shape (for reference)
 * {
 *   id: string,
 *   title: string,
 *   project?: string,
 *   tags?: string[],
 *   createdAt: ISOString,
 *   updatedAt?: ISOString,
 *   messages: [{ role: 'user'|'sage', text: string, ts?: ISOString }]
 * }
 */

export default function HistoryPanel({
  isOpen,
  onClose,
  onLoadConversation, // (chat) => void
}) {
  const [items, setItems] = useState([]);
  const [q, setQ] = useState("");
  const [projectFilter, setProjectFilter] = useState("all");
  const [tagFilter, setTagFilter] = useState("all");
  const [sortBy, setSortBy] = useState("updated"); // 'updated' | 'created' | 'title'
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [newProject, setNewProject] = useState("");
  const [newTag, setNewTag] = useState("");

  // load/save
  useEffect(() => {
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (raw) setItems(JSON.parse(raw));
    } catch {}
  }, []);
  useEffect(() => {
    try {
      localStorage.setItem(LS_KEY, JSON.stringify(items));
    } catch {}
  }, [items]);

  // derived facets
  const allProjects = useMemo(() => {
    const s = new Set(items.map((i) => i.project).filter(Boolean));
    return ["all", ...Array.from(s).sort()];
  }, [items]);

  const allTags = useMemo(() => {
    const s = new Set();
    items.forEach((i) => (i.tags || []).forEach((t) => s.add(t)));
    return ["all", ...Array.from(s).sort()];
  }, [items]);

  const filtered = useMemo(() => {
    const text = q.trim().toLowerCase();
    let rs = items.filter((i) => {
      if (projectFilter !== "all" && i.project !== projectFilter) return false;
      if (tagFilter !== "all" && !(i.tags || []).includes(tagFilter)) return false;
      if (!text) return true;
      const hay =
        `${i.title} ${(i.project || "")} ${(i.tags || []).join(" ")} ${i.messages
          ?.map((m) => m.text)
          .join(" ")}`.toLowerCase();
      return hay.includes(text);
    });
    rs.sort((a, b) => {
      if (sortBy === "title") return (a.title || "").localeCompare(b.title || "");
      const aT = new Date(a.updatedAt || a.createdAt).getTime();
      const bT = new Date(b.updatedAt || b.createdAt).getTime();
      if (sortBy === "created") return bT - aT; // newest first
      return bT - aT; // updated default
    });
    return rs;
  }, [items, q, projectFilter, tagFilter, sortBy]);

  // selection helpers
  const toggleOne = (id) =>
    setSelectedIds((s) => {
      const n = new Set(s);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });
  const clearSelection = () => setSelectedIds(new Set());

  // actions
  const deleteSelected = () => {
    if (selectedIds.size === 0) return;
    setItems((prev) => prev.filter((i) => !selectedIds.has(i.id)));
    clearSelection();
  };

  const exportSelectedJSON = () => {
    const rows = items.filter((i) => selectedIds.has(i.id));
    download(
      `brahma-chats-${rows.length || "none"}.json`,
      JSON.stringify(rows.length ? rows : items, null, 2),
      "application/json"
    );
  };
  const exportSelectedCSV = () => {
    const rows = items.filter((i) => selectedIds.has(i.id));
    download(
      `brahma-chats-${rows.length || "all"}.csv`,
      toCSV(rows.length ? rows : items),
      "text/csv"
    );
  };

  const updateItem = (id, patch) =>
    setItems((prev) =>
      prev.map((i) => (i.id === id ? { ...i, ...patch, updatedAt: new Date().toISOString() } : i))
    );

  const addProjectToSelected = () => {
    if (!newProject.trim()) return;
    setItems((prev) =>
      prev.map((i) => (selectedIds.has(i.id) ? { ...i, project: newProject.trim() } : i))
    );
    setNewProject("");
  };
  const addTagToSelected = () => {
    if (!newTag.trim()) return;
    setItems((prev) =>
      prev.map((i) =>
        selectedIds.has(i.id)
          ? { ...i, tags: Array.from(new Set([...(i.tags || []), newTag.trim()])) }
          : i
      )
    );
    setNewTag("");
  };

  // UI — slide-over panel
  return (
    <div
      className={`fixed inset-0 z-40 ${isOpen ? "" : "pointer-events-none"}`}
      aria-hidden={!isOpen}
    >
      {/* backdrop */}
      <div
        className={`absolute inset-0 transition ${
          isOpen ? "bg-black/40 backdrop-blur-sm" : "bg-transparent"
        }`}
        onClick={onClose}
      />
      {/* panel */}
      <aside
        className={`absolute right-0 top-0 h-full w-[420px] sm:w-[520px] bg-gradient-to-b from-[#281a44]/95 via-[#1c1433]/95 to-[#120e24]/95
          border-l border-white/10 shadow-2xl transition-transform duration-300
          ${isOpen ? "translate-x-0" : "translate-x-full"}`}
      >
        {/* header */}
        <div className="p-5 border-b border-white/10">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold bg-gradient-to-r from-blue-200 to-pink-200 bg-clip-text text-transparent">
              Chat History
            </h2>
            <button
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 border border-white/10"
            >
              Close
            </button>
          </div>

          {/* search & filters */}
          <div className="mt-4 grid grid-cols-2 gap-2">
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search title, tags, content…"
              className="col-span-2 bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-sm placeholder-purple-200/60 focus:outline-none focus:ring-2 focus:ring-purple-400/40"
            />
            <select
              value={projectFilter}
              onChange={(e) => setProjectFilter(e.target.value)}
              className="bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-sm"
            >
              {allProjects.map((p) => (
                <option key={p} value={p}>
                  {p === "all" ? "All projects" : p}
                </option>
              ))}
            </select>
            <select
              value={tagFilter}
              onChange={(e) => setTagFilter(e.target.value)}
              className="bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-sm"
            >
              {allTags.map((t) => (
                <option key={t} value={t}>
                  {t === "all" ? "All tags" : t}
                </option>
              ))}
            </select>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="col-span-2 bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-sm"
            >
              <option value="updated">Sort: Last updated</option>
              <option value="created">Sort: Created</option>
              <option value="title">Sort: Title</option>
            </select>
          </div>

          {/* bulk actions */}
          <div className="mt-3 flex flex-wrap gap-2">
            <button
              onClick={deleteSelected}
              className="px-3 py-1.5 text-sm rounded-lg bg-red-600/80 hover:bg-red-600 text-white disabled:opacity-40"
              disabled={selectedIds.size === 0}
            >
              Delete selected
            </button>
            <button
              onClick={exportSelectedJSON}
              className="px-3 py-1.5 text-sm rounded-lg bg-white/10 hover:bg-white/20 border border-white/10"
            >
              Export JSON
            </button>
            <button
              onClick={exportSelectedCSV}
              className="px-3 py-1.5 text-sm rounded-lg bg-white/10 hover:bg-white/20 border border-white/10"
            >
              Export CSV
            </button>
            <div className="flex items-center gap-1">
              <input
                value={newProject}
                onChange={(e) => setNewProject(e.target.value)}
                placeholder="Add project to selected"
                className="bg-white/10 border border-white/20 rounded-lg px-3 py-1.5 text-sm w-40"
              />
              <button
                onClick={addProjectToSelected}
                className="px-2 py-1.5 text-sm rounded-lg bg-white/10 hover:bg-white/20 border border-white/10"
              >
                Add
              </button>
            </div>
            <div className="flex items-center gap-1">
              <input
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                placeholder="Add tag to selected"
                className="bg-white/10 border border-white/20 rounded-lg px-3 py-1.5 text-sm w-40"
              />
              <button
                onClick={addTagToSelected}
                className="px-2 py-1.5 text-sm rounded-lg bg-white/10 hover:bg-white/20 border border-white/10"
              >
                Add
              </button>
            </div>
          </div>
        </div>

        {/* list */}
        <div className="overflow-y-auto h-[calc(100%-190px)] p-4 space-y-2">
          {filtered.length === 0 && (
            <div className="text-center text-purple-200/70 text-sm py-10">
              No conversations yet.
            </div>
          )}
          {filtered.map((c) => (
            <div
              key={c.id}
              className="bg-white/8 hover:bg-white/12 border border-white/10 rounded-lg p-3 transition group"
            >
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={selectedIds.has(c.id)}
                  onChange={() => toggleOne(c.id)}
                />
                <input
                  value={c.title || ""}
                  onChange={(e) => updateItem(c.id, { title: e.target.value })}
                  placeholder="Untitled conversation"
                  className="flex-1 bg-transparent text-sm outline-none"
                />
              </div>

              <div className="mt-2 flex flex-wrap items-center gap-2 text-[11px] text-purple-200/80">
                <span className="px-2 py-0.5 rounded bg-white/10 border border-white/10">
                  {(c.project && `📁 ${c.project}`) || "No project"}
                </span>
                {(c.tags || []).map((t) => (
                  <span
                    key={t}
                    className="px-2 py-0.5 rounded bg-white/10 border border-white/10"
                  >
                    #{t}
                  </span>
                ))}
                <span className="ml-auto">
                  {new Date(c.updatedAt || c.createdAt).toLocaleString()}
                </span>
              </div>

              <div className="mt-2 flex gap-2">
                <button
                  onClick={() => onLoadConversation?.(c)}
                  className="px-3 py-1.5 text-sm rounded-lg bg-purple-600/80 hover:bg-purple-600 text-white"
                >
                  Load
                </button>
                <button
                  onClick={() => updateItem(c.id, { project: "" })}
                  className="px-3 py-1.5 text-sm rounded-lg bg-white/10 hover:bg-white/20 border border-white/10"
                >
                  Clear project
                </button>
                <button
                  onClick={() =>
                    updateItem(c.id, { tags: [] })
                  }
                  className="px-3 py-1.5 text-sm rounded-lg bg-white/10 hover:bg-white/20 border border-white/10"
                >
                  Clear tags
                </button>
                <button
                  onClick={() =>
                    setItems((prev) => prev.filter((i) => i.id !== c.id))
                  }
                  className="ml-auto px-3 py-1.5 text-sm rounded-lg bg-red-600/80 hover:bg-red-600 text-white"
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      </aside>
    </div>
  );
}

/** Utility you can import elsewhere to save a chat */
export function saveConversationToHistory(chat) {
  try {
    const raw = localStorage.getItem(LS_KEY);
    const list = raw ? JSON.parse(raw) : [];
    const now = new Date().toISOString();
    const record = {
      id: chat.id || cryptoId(),
      title: chat.title || "Untitled conversation",
      project: chat.project || "",
      tags: chat.tags || [],
      createdAt: chat.createdAt || now,
      updatedAt: now,
      messages: chat.messages || [],
    };
    const next = [record, ...list.filter((x) => x.id !== record.id)];
    localStorage.setItem(LS_KEY, JSON.stringify(next));
    return record.id;
  } catch {
    return null;
  }
}

function cryptoId() {
  try {
    return crypto.randomUUID();
  } catch {
    return Math.random().toString(36).slice(2);
  }
}
