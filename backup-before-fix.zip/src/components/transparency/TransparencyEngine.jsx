// src/components/transparency/TransparencyEngine.jsx
import React, { useEffect, useRef, useState } from "react";

/* --------------------------- Particle Background --------------------------- */
const ParticleBackground = () => {
  const canvasRef = useRef(null);
  const particlesRef = useRef([]);
  const animationRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      initParticles();
    };
    window.addEventListener("resize", resize);

    const initParticles = () => {
      particlesRef.current = [];
      const n = Math.min(60, Math.floor((canvas.width * canvas.height) / 15000));
      for (let i = 0; i < n; i++) {
        particlesRef.current.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random() - 0.5) * 0.5,
          vy: (Math.random() - 0.5) * 0.5,
          size: Math.random() * 3 + 1,
          color: `hsl(${240 + Math.random() * 60},70%,70%)`,
          opShift: Math.random() * Math.PI * 2,
        });
      }
    };

    const tick = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // points
      particlesRef.current.forEach((p, i) => {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x <= 0 || p.x >= canvas.width) p.vx *= -1;
        if (p.y <= 0 || p.y >= canvas.height) p.vy *= -1;

        const opacity = 0.3 + Math.sin(Date.now() * 0.001 + p.opShift) * 0.2;

        ctx.save();
        ctx.globalAlpha = opacity;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      // links
      for (let i = 0; i < particlesRef.current.length; i++) {
        for (let j = i + 1; j < particlesRef.current.length; j++) {
          const a = particlesRef.current[i];
          const b = particlesRef.current[j];
          const dx = a.x - b.x;
          const dy = a.y - b.y;
          const d = Math.hypot(dx, dy);
          if (d < 150) {
            ctx.save();
            ctx.globalAlpha = 0.1 * (1 - d / 150);
            ctx.strokeStyle = "#8E7BEF";
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.stroke();
            ctx.restore();
          }
        }
      }

      animationRef.current = requestAnimationFrame(tick);
    };

    resize();
    tick();
    return () => {
      window.removeEventListener("resize", resize);
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-0"
      style={{ background: "transparent" }}
    />
  );
};

/* -------------------------------- Badges ---------------------------------- */
const PrivacyBadge = ({ hasLifetimePrivacy = false }) => (
  <div className="fixed top-4 right-4 bg-white/10 backdrop-blur-md rounded-full px-4 py-2 z-40 border border-white/20">
    <div className="flex items-center gap-2">
      <div
        className={`w-2 h-2 ${
          hasLifetimePrivacy ? "bg-emerald-400" : "bg-green-400"
        } rounded-full animate-pulse`}
      />
      <span className="text-xs text-white font-medium">
        {hasLifetimePrivacy ? "Privacy: Lifetime Protected 🔒" : "Privacy: Local Only"}
      </span>
    </div>
  </div>
);

/* ------------------------------ Data Shadow ------------------------------- */
const DataShadowPanel = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState("tracking");
  const dataValue = 47.23;
  const trackingData = [
    { source: "Browser Fingerprinting", frequency: "Continuous", value: "$12.40/month", risk: "High" },
    { source: "Location History", frequency: "Every 15 min", value: "$8.90/month", risk: "Medium" },
    { source: "Search Patterns", frequency: "Per query", value: "$15.20/month", risk: "High" },
    { source: "Device Analytics", frequency: "Real-time", value: "$6.80/month", risk: "Low" },
    { source: "Social Graph", frequency: "Daily sync", value: "$3.93/month", risk: "Medium" },
  ];
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 max-w-4xl w-full max-h-[90vh] overflow-hidden border border-white/20 shadow-2xl">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">Data Shadow Panel</h2>
            <p className="text-gray-300 text-sm">See what's being collected about you</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors text-xl">✕</button>
        </div>

        <div className="flex space-x-1 mb-6 bg-white/10 rounded-xl p-1">
          {["tracking", "value", "protection"].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-all ${
                activeTab === tab
                  ? "bg-purple-600/50 text-white"
                  : "text-gray-300 hover:text-white hover:bg-white/10"
              }`}
            >
              {tab === "tracking" ? "Passive Tracking" : tab === "value" ? "Data Value" : "Protection Status"}
            </button>
          ))}
        </div>

        <div className="overflow-y-auto max-h-96">
          {activeTab === "tracking" && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold text-white">Active Data Collection</h3>
                <div className="text-xs text-red-400">⚠️ {trackingData.length} sources detected</div>
              </div>
              <div className="space-y-3">
                {trackingData.map((item, i) => (
                  <div key={i} className="bg-white/5 rounded-xl p-4 border border-white/10">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-medium text-white">{item.source}</h4>
                      <span
                        className={`text-xs px-2 py-1 rounded-full ${
                          item.risk === "High"
                            ? "bg-red-500/20 text-red-400"
                            : item.risk === "Medium"
                            ? "bg-yellow-500/20 text-yellow-400"
                            : "bg-green-500/20 text-green-400"
                        }`}
                      >
                        {item.risk} Risk
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Frequency: {item.frequency}</span>
                      <span className="text-emerald-400 font-medium">{item.value}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === "value" && (
            <div className="space-y-6 text-center">
              <div className="text-4xl font-bold text-white mb-2">${dataValue.toFixed(2)}</div>
              <p className="text-gray-300 text-sm mb-4">Estimated monthly value of your data</p>
              <div className="bg-white/10 rounded-xl p-4">
                <p className="text-xs text-gray-400 mb-3">Based on industry averages:</p>
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div><span className="text-gray-300">Search data:</span><span className="text-emerald-400 ml-2">$15.20</span></div>
                  <div><span className="text-gray-300">Location data:</span><span className="text-emerald-400 ml-2">$8.90</span></div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "protection" && (
            <div className="space-y-4 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-emerald-500 to-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🛡️</span>
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Local-Only Protection Active</h3>
              <p className="text-gray-300 text-sm">Your data remains on your device</p>
            </div>
          )}
        </div>

        <div className="mt-6 pt-4 border-t border-white/10">
          <div className="flex justify-between items-center">
            <div className="text-xs text-gray-400">Last updated: {new Date().toLocaleTimeString()}</div>
            <button
              onClick={onClose}
              className="bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded-lg text-white text-sm font-medium transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

/* --------------------------- Lifetime Privacy UI --------------------------- */
const LifetimePrivacyContract = ({ onActivate, onClose }) => {
  const [signature, setSignature] = useState("");
  const [isActivating, setIsActivating] = useState(false);
  const [hasRead, setHasRead] = useState(false);

  const handleActivate = () => {
    if (!signature.trim()) return;
    setIsActivating(true);
    setTimeout(() => {
      onActivate({
        signature: signature.trim(),
        timestamp: new Date().toISOString(),
        contractVersion: "1.0",
      });
      setIsActivating(false);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-white/20 shadow-2xl">
        <div className="text-center mb-6">
          <div className="text-3xl mb-3">🔒</div>
          <h2 className="text-2xl font-bold text-white mb-2">Lifetime Privacy Contract</h2>
          <p className="text-gray-300 text-sm">Your data sovereignty, permanently protected</p>
        </div>

        <div className="space-y-6 mb-8">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
            <h3 className="text-lg font-semibold text-white mb-4">Welcome to Brahma.</h3>
            <p className="text-gray-200 mb-4">
              We believe your data is your own — not a product, not a training set, not a commodity.
            </p>
            <div className="space-y-4 text-gray-200">
              <div>
                <h4 className="font-semibold text-white mb-2">By activating Lifetime Privacy Mode:</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2"><span className="text-emerald-400 mt-1">•</span><span>Keep your data local to your device</span></li>
                  <li className="flex items-start gap-2"><span className="text-emerald-400 mt-1">•</span><span>Prevent AI training on your data</span></li>
                  <li className="flex items-start gap-2"><span className="text-emerald-400 mt-1">•</span><span>No third-party sharing</span></li>
                </ul>
              </div>
              <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-lg p-4">
                <p className="text-white font-medium">Your privacy is your right.</p>
              </div>
            </div>
          </div>

          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
            <div className="flex items-start gap-3 mb-4">
              <input
                type="checkbox"
                id="privacy-agreement"
                checked={hasRead}
                onChange={(e) => setHasRead(e.target.checked)}
                className="mt-1 w-4 h-4"
              />
              <label htmlFor="privacy-agreement" className="text-sm text-gray-200 cursor-pointer">
                I agree to this Lifetime Privacy Contract
              </label>
            </div>
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-200">Signature:</label>
              <input
                type="text"
                value={signature}
                onChange={(e) => setSignature(e.target.value)}
                placeholder="Type your name to confirm"
                disabled={!hasRead}
                className="w-full bg-white/10 backdrop-blur-sm text-white placeholder-gray-400 px-4 py-3 rounded-xl border border-white/20 focus:outline-none focus:ring-2 focus:ring-purple-500 disabled:opacity-50"
              />
            </div>
          </div>
        </div>

        <div className="flex gap-4">
          <button
            onClick={handleActivate}
            disabled={!hasRead || !signature.trim() || isActivating}
            className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:opacity-50 disabled:cursor-not-allowed px-6 py-3 rounded-xl text-white font-medium transition-all flex items-center justify-center gap-2"
          >
            {isActivating ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Activating...</span>
              </>
            ) : (
              <>
                <span>🔒</span>
                <span>Activate Privacy Mode</span>
              </>
            )}
          </button>
          <button onClick={onClose} className="px-6 py-3 text-gray-400 hover:text-white transition-colors">
            Maybe Later
          </button>
        </div>
      </div>
    </div>
  );
};

/* -------------------------------- Sage Chat --------------------------------
   - scrollable container
   - Top/Bottom jump buttons
   - copy / TTS / stop / export (.md/.json)
   - optional like/dislike
--------------------------------------------------------------------------- */
const SageChat = ({
  conversations = [],
  onSendMessage,
  isTyping = false,
  userData,
  settings,
  onRegenerate,
  onFeedback,
  placeholder = "Share what's on your mind…",
  hideHeader = false,
}) => {
  const [input, setInput] = useState("");
  const [reactions, setReactions] = useState({});
  const scrollRef = useRef(null);

  const [showTop, setShowTop] = useState(false);
  const [showBottom, setShowBottom] = useState(false);

  // auto-scroll on new messages (if near bottom)
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 120;
    if (nearBottom || settings?.reducedMotion) {
      el.scrollTo({ top: el.scrollHeight, behavior: settings?.reducedMotion ? "auto" : "smooth" });
    }
  }, [conversations, isTyping, settings?.reducedMotion]);

  // show/hide arrows
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const handle = () => {
      const atTop = el.scrollTop <= 8;
      const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight <= 8;
      setShowTop(!atTop);
      setShowBottom(!atBottom);
    };
    handle();
    el.addEventListener("scroll", handle, { passive: true });
    return () => el.removeEventListener("scroll", handle);
  }, []);

  const toast = (msg) => {
    const d = document.createElement("div");
    d.className =
      "fixed top-4 left-1/2 -translate-x-1/2 bg-black/80 text-white border border-white/20 px-3 py-1.5 rounded-lg text-xs z-50";
    d.textContent = msg;
    document.body.appendChild(d);
    setTimeout(() => d.remove(), 1200);
  };

  const copyToClipboard = async (text) => {
    try {
      await navigator.clipboard.writeText(text || "");
      toast("Copied to clipboard");
    } catch {
      toast("Copy failed");
    }
  };

  const speak = (text) => {
    try {
      if (!text) return;
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.rate = 1;
      u.pitch = 1;
      u.lang = "en-US";
      window.speechSynthesis.speak(u);
    } catch {
      toast("Text-to-speech not available");
    }
  };
  const stopSpeaking = () => {
    try {
      window.speechSynthesis.cancel();
    } catch {}
  };
  useEffect(() => () => stopSpeaking(), []);

  const download = (content, filename, type) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    toast("Export ready");
  };
  const exportMarkdown = () => {
    const title = `Brahma Chat ${new Date().toLocaleString()}`;
    const lines = [`# ${title}`, ""];
    conversations.forEach((m, i) => {
      if (m.user) lines.push(`**You:** ${m.user}`);
      if (m.sage) lines.push(`**${userData?.sage?.name || "Sage"}:** ${m.sage}`);
      if (i < conversations.length - 1) lines.push("");
    });
    download(lines.join("\n"), `brahma-chat-${Date.now()}.md`, "text/markdown");
  };
  const exportJSON = () => {
    const payload = {
      title: `Brahma Chat`,
      createdAt: new Date().toISOString(),
      messages: conversations,
      sage: userData?.sage || { name: "Sage" },
    };
    download(JSON.stringify(payload, null, 2), `brahma-chat-${Date.now()}.json`, "application/json");
  };

  const handleSend = () => {
    const text = input.trim();
    if (!text) return;
    stopSpeaking();
    onSendMessage?.(text);
    setInput("");
  };

  const handleRegenerate = () => {
    stopSpeaking();
    const lastUser = [...conversations].reverse().find((m) => m.user)?.user || input.trim();
    if (!lastUser) return toast("Nothing to regenerate");
    if (onRegenerate) onRegenerate(lastUser);
    else onSendMessage?.(lastUser);
  };

  const setReaction = (key, value) => {
    setReactions((p) => ({ ...p, [key]: p[key] === value ? undefined : value }));
  };

  const scrollToTop = () => scrollRef.current?.scrollTo({ top: 0, behavior: "smooth" });
  const scrollToBottom = () =>
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });

  return (
    <div className="flex flex-col h-[560px] relative">
      {/* Top actions */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-white/10 bg-gradient-to-r from-purple-600/10 to-pink-600/10">
        <div className="text-xs text-gray-300">
          {userData?.sage?.name || "Sage"} is privacy-first • Local only
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleRegenerate}
            className="px-2.5 py-1.5 text-xs rounded-md bg-white/10 hover:bg-white/20 border border-white/20"
            title="Regenerate last answer"
          >
            ↻ Regenerate
          </button>
          <div className="h-4 w-px bg-white/20" />
          <button
            onClick={exportMarkdown}
            className="px-2.5 py-1.5 text-xs rounded-md bg-white/10 hover:bg-white/20 border border-white/20"
            title="Export as Markdown"
          >
            ⤓ .md
          </button>
          <button
            onClick={exportJSON}
            className="px-2.5 py-1.5 text-xs rounded-md bg-white/10 hover:bg-white/20 border border-white/20"
            title="Export as JSON"
          >
            ⤓ .json
          </button>
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 scroll-smooth">
        {conversations.length === 0 && !hideHeader ? (
          <div className="text-center text-sm text-gray-400 py-16">
            Start a conversation—your decisions stay yours. Your wisdom stays local.
          </div>
        ) : null}

        {conversations.map((m, idx) => (
          <div key={idx} className="space-y-2">
            {m.user?.trim() ? (
              <div className="flex justify-end">
                <div className="max-w-[80%] bg-blue-500/20 border border-blue-400/30 rounded-xl px-3 py-2 text-sm text-blue-100">
                  {m.user}
                </div>
              </div>
            ) : null}

            {m.sage?.trim() ? (
              <div className="group flex items-start gap-2">
                <div className="h-8 w-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white text-xs shrink-0">
                  {(userData?.sage?.name || "S")[0]}
                </div>
                <div className="relative max-w-[82%] bg-white/5 border border-white/10 rounded-xl px-3 py-2">
                  <div className="prose prose-invert prose-sm max-w-none text-gray-100">{m.sage}</div>

                  <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-2 right-2 flex items-center gap-1">
                    <button
                      onClick={() => copyToClipboard(m.sage)}
                      className="px-2 py-1 text-[11px] rounded bg-white/10 hover:bg-white/20 border border-white/20"
                      title="Copy"
                    >
                      ⧉
                    </button>
                    <button
                      onClick={() => speak(m.sage)}
                      className="px-2 py-1 text-[11px] rounded bg-white/10 hover:bg-white/20 border border-white/20"
                      title="Text-to-Speech"
                    >
                      🔊
                    </button>
                    <button
                      onClick={stopSpeaking}
                      className="px-2 py-1 text-[11px] rounded bg-white/10 hover:bg-white/20 border border-white/20"
                      title="Stop speech"
                    >
                      ⏹
                    </button>
                    <div className="h-3 w-px bg-white/20 mx-1" />
                    <button
                      onClick={() => {
                        setReaction(`${idx}-sage`, "like");
                        onFeedback?.({ index: idx, role: "sage", value: "like" });
                      }}
                      className={`px-2 py-1 text-[11px] rounded border ${
                        reactions[`${idx}-sage`] === "like"
                          ? "bg-emerald-600/70 border-emerald-400 text-white"
                          : "bg-white/10 hover:bg-white/20 border-white/20"
                      }`}
                      title="Like"
                    >
                      👍
                    </button>
                    <button
                      onClick={() => {
                        setReaction(`${idx}-sage`, "dislike");
                        onFeedback?.({ index: idx, role: "sage", value: "dislike" });
                      }}
                      className={`px-2 py-1 text-[11px] rounded border ${
                        reactions[`${idx}-sage`] === "dislike"
                          ? "bg-rose-600/70 border-rose-400 text-white"
                          : "bg-white/10 hover:bg-white/20 border-white/20"
                      }`}
                      title="Dislike"
                    >
                      👎
                    </button>
                  </div>
                </div>
              </div>
            ) : null}
          </div>
        ))}

        {isTyping && (
          <div className="flex items-center gap-2 text-gray-300 text-sm">
            <span className="inline-flex -space-x-1">
              <Dot /> <Dot delay="150ms" /> <Dot delay="300ms" />
            </span>
            {userData?.sage?.name || "Sage"} is thinking…
          </div>
        )}
      </div>

      {/* Floating scroll helpers */}
      {showTop && (
        <button
          onClick={scrollToTop}
          className="absolute right-4 top-16 z-20 bg-white/10 hover:bg-white/20 border border-white/20 backdrop-blur px-2.5 py-1.5 rounded-full text-xs"
          title="Scroll to top"
        >
          ⬆︎ Top
        </button>
      )}
      {showBottom && (
        <button
          onClick={scrollToBottom}
          className="absolute right-4 bottom-20 z-20 bg-white/10 hover:bg-white/20 border border-white/20 backdrop-blur px-2.5 py-1.5 rounded-full text-xs"
          title="Scroll to bottom"
        >
          ⬇︎ Bottom
        </button>
      )}

      {/* Input */}
      <div className="p-4 border-t border-white/10">
        <div className="flex items-center gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            })}
            placeholder={placeholder}
            className="flex-1 bg-white/10 text-white placeholder-gray-400 px-4 py-3 rounded-xl border border-white/20 focus:ring-2 focus:ring-purple-500 outline-none"
          />
          <button
            onClick={handleSend}
            className="px-4 py-3 rounded-xl bg-purple-600 hover:bg-purple-700 text-white border border-white/20"
          >
            Send
          </button>
        </div>
      </div>
    </div>
  );
};

const Dot = ({ delay = "0ms" }) => (
  <span className="inline-block w-1.5 h-1.5 rounded-full bg-white/70 animate-bounce" style={{ animationDelay: delay }} />
);

/* --------------------------- Reflection Sandbox ---------------------------- */
const ReflectionSandbox = ({ option, onClose, onReturnToMain, mainConversations }) => {
  const [sandboxConversations, setSandboxConversations] = useState([]);
  const [isTyping, setIsTyping] = useState(false);
  const [assumptions, setAssumptions] = useState({
    timeframe: option?.timeframe || "6 months",
    budget: option?.budget || "flexible",
    riskTolerance: option?.riskTolerance || "moderate",
    priority: option?.priority || "balanced",
  });
  const [explorationFocus, setExplorationFocus] = useState("");

  const focusOptions = [
    { id: "worst-case", label: "Worst Case Scenarios", emoji: "⚠️", description: "What if everything goes wrong?" },
    { id: "best-case", label: "Best Case Outcomes", emoji: "✨", description: "What if everything aligns perfectly?" },
    { id: "timeline", label: "Timeline Deep Dive", emoji: "📅", description: "How does timing affect this path?" },
    { id: "resources", label: "Resource Requirements", emoji: "🛠️", description: "What will this really take?" },
    { id: "relationships", label: "Impact on Relationships", emoji: "👥", description: "How does this affect others?" },
    { id: "values", label: "Values Alignment", emoji: "💎", description: "Does this honor who I am?" },
  ];

  const handleSendMessage = (message) => {
    const newConversation = { user: message, sage: "" };
    setSandboxConversations((prev) => [...prev, newConversation]);
    setIsTyping(true);

    setTimeout(() => {
      const contextual = {
        "worst-case": [
          "Let's explore that fear together. What specifically worries you most about this path?",
          "What if the worst case happened — how might you respond or recover?",
        ],
        "best-case": [
          "That sounds exciting. What would success really look like for you?",
          "If everything went perfectly, how would you know you chose well?",
        ],
        timeline: [
          "Time has its own wisdom. What feels urgent versus what can wait?",
          "How does this timeline honor your needs and constraints?",
        ],
        resources: [
          "What support would make this feel more possible?",
          "What resources do you already have that you might be overlooking?",
        ],
        relationships: [
          "Who else is affected by this choice? How does that sit with you?",
          "What conversations might need to happen?",
        ],
        values: [
          "What values are you trying to honor here?",
          "What would you choose if you knew you couldn't fail?",
        ],
      };

      const responses = contextual[explorationFocus] || [
        "I'm here to explore this with you. What aspect feels most important right now?",
      ];
      const response = responses[Math.floor(Math.random() * responses.length)];

      setSandboxConversations((prev) => {
        const updated = [...prev];
        updated[updated.length - 1].sage = response;
        return updated;
      });
      setIsTyping(false);
    }, 1200);
  };

  const handleReturnWithInsights = () => {
    const insights = sandboxConversations.map((conv) => ({
      question: conv.user,
      reflection: conv.sage,
      focus: explorationFocus,
      timestamp: new Date().toISOString(),
    }));

    onReturnToMain({
      option,
      insights,
      adjustedAssumptions: assumptions,
      explorationSummary: `Explored ${option.title} through ${
        focusOptions.find((f) => f.id === explorationFocus)?.label
      } lens`,
      focusArea: explorationFocus,
    });
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white/10 backdrop-blur-md rounded-2xl max-w-7xl w-full max-h-[90vh] overflow-hidden border border-white/20 shadow-2xl">
        <div className="flex h-full max-h-[90vh]">
          {/* Left controls */}
          <div className="w-1/3 bg-blue-500/10 border-r border-white/10 p-6 overflow-y-auto">
            <div className="space-y-6">
              <div className="text-center">
                <div className="text-3xl mb-3">🔬</div>
                <h3 className="text-xl font-semibold text-white mb-2">Reflection Sandbox</h3>
                <p className="text-sm text-blue-200 mb-1">Private exploration space</p>
                <p className="text-xs text-gray-400">Exploring: "{option.title}"</p>
              </div>

              <div className="bg-white/10 rounded-xl p-4 border border-white/20">
                <h4 className="text-sm font-medium text-white mb-3">Choose Your Exploration Lens</h4>
                <div className="space-y-2">
                  {focusOptions.map((focus) => (
                    <button
                      key={focus.id}
                      onClick={() => setExplorationFocus(focus.id)}
                      className={`w-full text-left p-3 rounded-lg text-sm transition-all group ${
                        explorationFocus === focus.id
                          ? "bg-blue-500/30 text-white border border-blue-400"
                          : "bg-white/5 text-gray-300 hover:bg-white/10"
                      }`}
                    >
                      <div className="flex items-center gap-3 mb-1">
                        <span className="text-lg">{focus.emoji}</span>
                        <span className="font-medium">{focus.label}</span>
                      </div>
                      <p className="text-xs text-gray-400 group-hover:text-gray-300 ml-8">
                        {focus.description}
                      </p>
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-white/10 rounded-xl p-4 border border-white/20">
                <h4 className="text-sm font-medium text-white mb-3">Adjust Assumptions</h4>
                <div className="space-y-3">
                  <div>
                    <label className="text-xs text-gray-300">Timeframe</label>
                    <select
                      value={assumptions.timeframe}
                      onChange={(e) => setAssumptions((p) => ({ ...p, timeframe: e.target.value }))}
                      className="w-full mt-1 bg-white/10 text-white text-xs p-2 rounded border border-white/20"
                    >
                      <option value="immediate" className="text-black">Immediate</option>
                      <option value="3 months" className="text-black">3 months</option>
                      <option value="6 months" className="text-black">6 months</option>
                      <option value="1 year" className="text-black">1 year</option>
                      <option value="long-term" className="text-black">Long-term</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs text-gray-300">Risk Tolerance</label>
                    <select
                      value={assumptions.riskTolerance}
                      onChange={(e) => setAssumptions((p) => ({ ...p, riskTolerance: e.target.value }))}
                      className="w-full mt-1 bg-white/10 text-white text-xs p-2 rounded border border-white/20"
                    >
                      <option value="conservative" className="text-black">Conservative</option>
                      <option value="moderate" className="text-black">Moderate</option>
                      <option value="adventurous" className="text-black">Adventurous</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs text-gray-300">Budget Flexibility</label>
                    <select
                      value={assumptions.budget}
                      onChange={(e) => setAssumptions((p) => ({ ...p, budget: e.target.value }))}
                      className="w-full mt-1 bg-white/10 text-white text-xs p-2 rounded border border-white/20"
                    >
                      <option value="tight" className="text-black">Tight budget</option>
                      <option value="moderate" className="text-black">Some flexibility</option>
                      <option value="flexible" className="text-black">Very flexible</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="bg-purple-500/20 rounded-xl p-4 border border-purple-400/30">
                <h4 className="text-sm font-medium text-white mb-2">Connection to Main Thread</h4>
                <p className="text-xs text-purple-200 mb-3">
                  You've explored {mainConversations.length} thoughts in your main conversation.
                  This sandbox keeps your journey intact.
                </p>
                <div className="text-xs text-gray-300 space-y-1">
                  <div className="flex items-center gap-2"><span>🧵</span><span>Main thread preserved</span></div>
                  <div className="flex items-center gap-2"><span>🔒</span><span>Local exploration only</span></div>
                  <div className="flex items-center gap-2"><span>💭</span><span>Insights will be woven back</span></div>
                </div>
              </div>
            </div>
          </div>

          {/* Right chat */}
          <div className="w-2/3 flex flex-col">
            <div className="p-4 border-b border-white/10 bg-gradient-to-r from-blue-600/20 to-purple-600/20">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium text-white">Sandbox Exploration</h3>
                  <p className="text-xs text-gray-300">
                    {explorationFocus
                      ? `Focus: ${focusOptions.find((f) => f.id === explorationFocus)?.label}`
                      : "Choose a focus area to begin"}
                  </p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={handleReturnWithInsights}
                    disabled={sandboxConversations.length === 0}
                    className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:opacity-50 px-4 py-2 rounded-lg text-white text-sm font-medium transition-all"
                  >
                    Weave Back Insights
                  </button>
                  <button onClick={onClose} className="text-gray-400 hover:text-white text-xl transition-colors">
                    ✕
                  </button>
                </div>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4">
              {!explorationFocus ? (
                <div className="text-center py-12">
                  <div className="text-6xl mb-6">🎯</div>
                  <h4 className="text-xl font-medium text-white mb-3">Choose Your Exploration Lens</h4>
                  <p className="text-gray-300 text-sm max-w-md mx-auto">
                    Select a focus area to begin your deep dive into "{option.title}".
                  </p>
                </div>
              ) : sandboxConversations.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-5xl mb-6">💭</div>
                  <h4 className="text-xl font-medium text-white mb-3">Ready to Explore</h4>
                  <p className="text-gray-300 text-sm mb-6 max-w-md mx-auto">
                    What questions do you have about "{option.title}" through this lens?
                  </p>
                  <div className="bg-blue-500/20 rounded-xl p-4 max-w-md mx-auto border border-blue-400/30">
                    <p className="text-blue-200 text-xs">
                      This is your private exploration space. Nothing here affects your main
                      conversation until you weave insights back.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {sandboxConversations.map((c, i) => (
                    <div key={i} className="space-y-3">
                      <div className="flex justify-end">
                        <div className="bg-blue-600/30 backdrop-blur-sm rounded-2xl rounded-br-sm px-4 py-2 max-w-xs">
                          <p className="text-sm text-white">{c.user}</p>
                        </div>
                      </div>
                      {c.sage && (
                        <div className="flex justify-start">
                          <div className="bg-white/10 backdrop-blur-sm rounded-2xl rounded-bl-sm px-4 py-2 max-w-xs">
                            <p className="text-sm text-gray-200">{c.sage}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                  {isTyping && (
                    <div className="flex justify-start">
                      <div className="bg-white/10 backdrop-blur-sm rounded-2xl rounded-bl-sm px-4 py-2">
                        <div className="flex space-x-1">
                          <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" />
                          <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: "0.1s" }} />
                          <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }} />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {explorationFocus && (
              <SageChat
                conversations={sandboxConversations}
                onSendMessage={handleSendMessage}
                isTyping={isTyping}
                placeholder={`Explore ${option.title}…`}
                hideHeader
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

/* ------------------------------- Option Card ------------------------------- */
const OptionCard = ({ option, onExplore, onPin, onArchive, onOpenSandbox, isPinned }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  return (
    <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 hover:bg-white/15 transition-all border border-white/20">
      <div className="flex justify-between items-start mb-3">
        <h4 className="text-lg font-semibold text-white flex-1">{option.title}</h4>
        <div className="flex gap-2 ml-3">
          <button
            onClick={() => onOpenSandbox(option)}
            className="p-2 rounded-lg hover:bg-blue-500/20 text-blue-400 transition-colors"
            title="Open Reflection Sandbox"
          >
            🔬
          </button>
          <button
            onClick={() => onPin(option.id)}
            className={`p-2 rounded-lg transition-colors ${
              isPinned ? "bg-yellow-500/20 text-yellow-400" : "hover:bg-white/10 text-gray-400"
            }`}
            title={isPinned ? "Unpin" : "Pin"}
          >
            📌
          </button>
          <button
            onClick={() => onArchive(option.id)}
            className="p-2 rounded-lg hover:bg-white/10 text-gray-400 transition-colors"
            title="Archive"
          >
            🗃️
          </button>
        </div>
      </div>

      <p className="text-gray-300 text-sm mb-4">{option.description}</p>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="bg-white/5 rounded-lg p-3">
          <div className="text-xs text-gray-400 mb-1">Estimated Cost</div>
          <div className="text-sm font-medium text-emerald-400">{option.cost}</div>
        </div>
        <div className="bg-white/5 rounded-lg p-3">
          <div className="text-xs text-gray-400 mb-1">Risk Level</div>
          <div className="text-sm font-medium text-yellow-400">{option.risk}</div>
        </div>
      </div>

      {isExpanded && (
        <div className="border-t border-white/10 pt-4 space-y-3">
          <div>
            <h5 className="text-xs font-semibold text-gray-300 mb-2">Key Considerations</h5>
            <ul className="text-xs text-gray-400 space-y-1">
              {option.considerations?.map((c, i) => <li key={i}>• {c}</li>)}
            </ul>
          </div>
          <div>
            <h5 className="text-xs font-semibold text-gray-300 mb-2">Notes</h5>
            <p className="text-xs text-gray-400">{option.notes || "No additional notes"}</p>
          </div>
        </div>
      )}

      <div className="flex gap-3 mt-4">
        <button
          onClick={() => onExplore(option)}
          className="flex-1 bg-purple-600/30 hover:bg-purple-600/50 px-4 py-2 rounded-lg text-white text-sm font-medium transition-colors"
        >
          Explore This
        </button>
        <button
          onClick={() => setIsExpanded((v) => !v)}
          className="px-4 py-2 text-gray-400 hover:text-white text-sm transition-colors"
        >
          {isExpanded ? "Less" : "More"}
        </button>
      </div>
    </div>
  );
};

/* --------------------------- Transparency Engine --------------------------- */
const TransparencyEngine = () => {
  const [conversations, setConversations] = useState([]);
  const [isTyping, setIsTyping] = useState(false);
  const [options, setOptions] = useState([]);
  const [pinnedOptions, setPinnedOptions] = useState(new Set());
  const [currentView, setCurrentView] = useState("transparency");
  const [showPrivacyContract, setShowPrivacyContract] = useState(false);
  const [hasLifetimePrivacy, setHasLifetimePrivacy] = useState(false);
  const [showDataShadow, setShowDataShadow] = useState(false);
  const [activeSandbox, setActiveSandbox] = useState(null);
  const [sandboxInsights, setSandboxInsights] = useState([]);

  useEffect(() => {
    setOptions([
      {
        id: 1,
        title: "Take the remote position",
        description: "Accept the fully remote role with better compensation but less team interaction",
        cost: "$2k relocation savings",
        risk: "Medium",
        timeframe: "3 months",
        budget: "flexible",
        riskTolerance: "moderate",
        considerations: ["Less face-to-face collaboration", "Better work-life balance potential", "Higher compensation package"],
        notes: "Company has strong remote culture",
      },
      {
        id: 2,
        title: "Stay in current role",
        description: "Remain with current team and negotiate for better conditions",
        cost: "Opportunity cost of new role",
        risk: "Low",
        timeframe: "immediate",
        budget: "current",
        riskTolerance: "conservative",
        considerations: ["Familiar environment", "Known career progression", "May limit growth opportunities"],
        notes: "Current manager is supportive",
      },
    ]);
  }, []);

  const handleSendMessage = (message) => {
    const newConversation = { user: message, sage: "" };
    setConversations((prev) => [...prev, newConversation]);
    setIsTyping(true);

    setTimeout(() => {
      const responses = [
        "That's thoughtful. What feels most important to you in this decision?",
        "How does this align with your goals?",
        "What would help you feel more confident about this path?",
        "I hear the complexity here. What's drawing you toward clarity?",
      ];
      const response = responses[Math.floor(Math.random() * responses.length)];
      setConversations((prev) => {
        const updated = [...prev];
        updated[updated.length - 1].sage = response;
        return updated;
      });
      setIsTyping(false);
    }, 1000);
  };

  const handleExploreOption = (option) => {
    handleSendMessage(`I want to explore "${option.title}" more deeply.`);
  };
  const handleOpenSandbox = (option) => setActiveSandbox(option);
  const handleCloseSandbox = () => setActiveSandbox(null);

  const handleSandboxReturn = (sandboxData) => {
    setSandboxInsights((prev) => [...prev, sandboxData]);
    setActiveSandbox(null);

    const insightMessage = `I've been exploring "${sandboxData.option.title}" in a reflection sandbox, focusing on ${sandboxData.focusArea}. Here's what I discovered: ${sandboxData.explorationSummary}`;
    handleSendMessage(insightMessage);

    const t = document.createElement("div");
    t.className =
      "fixed top-4 right-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white px-4 py-3 rounded-xl z-50 shadow-2xl max-w-sm";
    t.innerHTML = `<p class="text-sm font-medium">🔬 Sandbox Insights Woven Back</p><p class="text-xs mt-1">${sandboxData.insights.length} reflections integrated into your main journey</p>`;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 4000);
  };

  const handlePinOption = (id) =>
    setPinnedOptions((prev) => {
      const s = new Set(prev);
      s.has(id) ? s.delete(id) : s.add(id);
      return s;
    });

  const handleArchiveOption = (id) => setOptions((prev) => prev.filter((o) => o.id !== id));

  const handleActivatePrivacy = (contractData) => {
    setHasLifetimePrivacy(true);
    setShowPrivacyContract(false);

    const t = document.createElement("div");
    t.className =
      "fixed top-4 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-emerald-600 to-green-600 text-white px-6 py-3 rounded-xl z-50 shadow-2xl max-w-sm text-center";
    t.innerHTML = `<p class="text-sm font-medium">🔒 Lifetime Privacy Activated</p><p class="text-xs mt-1">Welcome, ${contractData.signature}</p>`;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 3000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-black text-white relative overflow-hidden">
      <ParticleBackground />
      <PrivacyBadge hasLifetimePrivacy={hasLifetimePrivacy} />

      {/* soft glows */}
      <div className="fixed top-10 left-10 w-32 h-32 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-full blur-xl animate-pulse" />
      <div className="fixed bottom-10 right-10 w-40 h-40 bg-gradient-to-r from-pink-500/20 to-indigo-500/20 rounded-full blur-xl animate-pulse" />

      <div className="container mx-auto px-4 sm:px-6 py-8 relative z-10 max-w-7xl">
        <div className="text-center mb-8">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-3">
            Brahma Transparency Engine
          </h1>
          <p className="text-emerald-400 text-sm sm:text-base font-medium">
            Decision exploration • Guided reflection • Sage wisdom
          </p>
          <div className="mt-2 text-xs text-gray-400">Explore your choices with AI-powered transparency</div>

          <div className="mt-6 flex justify-center">
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-2 flex space-x-2 border border-white/20">
              <button
                onClick={() => setCurrentView("transparency")}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  currentView === "transparency"
                    ? "bg-purple-600/50 text-white"
                    : "text-gray-300 hover:text-white hover:bg-white/10"
                }`}
              >
                Decision Explorer
              </button>
              {!hasLifetimePrivacy && (
                <button
                  onClick={() => setShowPrivacyContract(true)}
                  className="px-4 py-2 rounded-lg text-sm font-medium text-emerald-300 hover:text-white hover:bg-emerald-600/20 transition-all border border-emerald-500/30"
                >
                  🔒 Privacy Mode
                </button>
              )}
              <button
                onClick={() => setShowDataShadow(true)}
                className="px-4 py-2 rounded-lg text-sm font-medium text-orange-300 hover:text-white hover:bg-orange-600/20 transition-all border border-orange-500/30"
              >
                🕵️ Data Shadow
              </button>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Chat */}
          <div className="bg-white/10 backdrop-blur-md rounded-xl overflow-hidden border border-white/20">
            <div className="bg-gradient-to-r from-purple-600/30 to-pink-600/30 p-4 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                  <span className="text-sm">🧙‍♀️</span>
                </div>
                <div>
                  <h3 className="font-semibold text-white">Sage</h3>
                  <p className="text-xs text-gray-300">Your decision companion</p>
                </div>
              </div>
            </div>

            <SageChat conversations={conversations} onSendMessage={handleSendMessage} isTyping={isTyping} />
          </div>

          {/* Options & insights */}
          <div className="space-y-4">
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-white">Decision Options</h3>
                <div className="text-xs text-gray-400">{options.length} paths • {pinnedOptions.size} pinned</div>
              </div>

              <div className="space-y-4 max-h-96 overflow-y-auto">
                {options.map((option) => (
                  <OptionCard
                    key={option.id}
                    option={option}
                    onExplore={handleExploreOption}
                    onPin={handlePinOption}
                    onArchive={handleArchiveOption}
                    onOpenSandbox={handleOpenSandbox}
                    isPinned={pinnedOptions.has(option.id)}
                  />
                ))}

                {sandboxInsights.length > 0 && (
                  <div className="border-t border-white/10 pt-4">
                    <h4 className="text-sm font-semibold text-blue-300 mb-3 flex items-center gap-2">
                      <span>🔬</span> Sandbox Insights
                    </h4>
                    {sandboxInsights.map((insight, index) => (
                      <div key={index} className="bg-blue-500/20 rounded-xl p-4 mb-3 border border-blue-400/30">
                        <div className="flex justify-between items-start mb-2">
                          <h5 className="text-sm font-medium text-blue-200">{insight.option.title}</h5>
                          <span className="text-xs text-gray-400">
                            {new Date(insight.insights[0]?.timestamp).toLocaleDateString()}
                          </span>
                        </div>
                        <p className="text-xs text-blue-100 mb-2">{insight.explorationSummary}</p>
                        <div className="text-xs text-gray-300">💭 {insight.insights.length} reflections explored</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-md rounded-xl p-4 border border-white/20">
              <h4 className="text-sm font-semibold text-gray-300 mb-3">Quick Actions</h4>
              <div className="grid grid-cols-2 gap-2">
                <button className="bg-white/10 hover:bg-white/20 px-3 py-2 rounded-lg text-xs transition-colors">📊 Compare Options</button>
                <button className="bg-white/10 hover:bg-white/20 px-3 py-2 rounded-lg text-xs transition-colors">⚖️ Pros & Cons</button>
                <button className="bg-white/10 hover:bg-white/20 px-3 py-2 rounded-lg text-xs transition-colors">🎯 Values Check</button>
                <button className="bg-white/10 hover:bg-white/20 px-3 py-2 rounded-lg text-xs transition-colors">🔮 Future Scenario</button>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center text-xs text-gray-500 mt-8">
          <p>© 2025 Brahma • Relationship Infrastructure for Human Dignity</p>
          <p className="mt-1">Your decisions stay yours. Your wisdom stays local.</p>
        </div>
      </div>

      {showPrivacyContract && (
        <LifetimePrivacyContract onActivate={handleActivatePrivacy} onClose={() => setShowPrivacyContract(false)} />
      )}

      {showDataShadow && <DataShadowPanel isOpen={showDataShadow} onClose={() => setShowDataShadow(false)} />}

      {activeSandbox && (
        <ReflectionSandbox
          option={activeSandbox}
          onClose={handleCloseSandbox}
          onReturnToMain={handleSandboxReturn}
          mainConversations={conversations}
        />
      )}
    </div>
  );
};

export default TransparencyEngine;