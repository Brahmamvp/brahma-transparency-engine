// src/components/transparency/SettingsPanel.jsx
import React, { useEffect, useMemo, useState } from "react";
import {
  X,
  Cog,
  Monitor,
  SlidersHorizontal,
  Mic,
  Database,
  Download,
  Upload,
  Trash2,
  Info,
  CheckCircle2,
  AlertTriangle,
} from "lucide-react";

// Optional modals (provided separately)
import EchoSettings from "./EchoSettings.jsx";
import VoiceModulator from "./VoiceModulator.jsx";

/**
 * SettingsPanel
 *
 * Props:
 *  - onClose: () => void
 *  - userData?: any
 *  - onSettingsChange: (key: 'showParticles'|'showAvatar'|'reducedMotion', value: boolean) => void
 *
 * Reads/writes some preferences from localStorage for persistence.
 */
const SettingsPanel = ({ onClose, userData, onSettingsChange }) => {
  const [activeTab, setActiveTab] = useState("general");

  // UI prefs (mirrors what TransparencyEngine consumes)
  const [showParticles, setShowParticles] = useState(
    localStorage.getItem("brahma_show_particles") !== "false"
  );
  const [showAvatar, setShowAvatar] = useState(
    localStorage.getItem("brahma_show_avatar") !== "false"
  );
  const [reducedMotion, setReducedMotion] = useState(
    localStorage.getItem("brahma_reduced_motion") === "true"
  );

  // Voice & Echo sub-modals
  const [showEcho, setShowEcho] = useState(false);
  const [showVoice, setShowVoice] = useState(false);

  // Memory tab local state
  const [memoryEnabled, setMemoryEnabled] = useState(
    localStorage.getItem("brahma_memory_enabled") !== "false"
  );
  const [memoryMode, setMemoryMode] = useState(
    localStorage.getItem("brahma_memory_mode") || "contextual"
  ); // off|contextual|insight|full
  const [memoryDuration, setMemoryDuration] = useState(
    localStorage.getItem("brahma_memory_duration") || "90" // days; 7|30|90|365|forever
  );
  const [scope, setScope] = useState(() => {
    try {
      return JSON.parse(
        localStorage.getItem("brahma_memory_scope") ||
          '{"reflections":true,"decisions":true,"emotions":true,"conversations":true}'
      );
    } catch {
      return {
        reflections: true,
        decisions: true,
        emotions: true,
        conversations: true,
      };
    }
  });

  // Persist UI prefs to localStorage and notify parent
  useEffect(() => {
    localStorage.setItem("brahma_show_particles", showParticles ? "true" : "false");
    onSettingsChange?.("showParticles", !!showParticles);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showParticles]);

  useEffect(() => {
    localStorage.setItem("brahma_show_avatar", showAvatar ? "true" : "false");
    onSettingsChange?.("showAvatar", !!showAvatar);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showAvatar]);

  useEffect(() => {
    localStorage.setItem("brahma_reduced_motion", reducedMotion ? "true" : "false");
    onSettingsChange?.("reducedMotion", !!reducedMotion);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reducedMotion]);

  // Persist memory prefs
  useEffect(() => {
    localStorage.setItem("brahma_memory_enabled", memoryEnabled ? "true" : "false");
  }, [memoryEnabled]);

  useEffect(() => {
    localStorage.setItem("brahma_memory_mode", memoryMode);
  }, [memoryMode]);

  useEffect(() => {
    localStorage.setItem("brahma_memory_duration", memoryDuration);
  }, [memoryDuration]);

  useEffect(() => {
    try {
      localStorage.setItem("brahma_memory_scope", JSON.stringify(scope));
    } catch {}
  }, [scope]);

  // Read Echo summary (for preview chip)
  const echoSummary = useMemo(() => {
    try {
      const raw = JSON.parse(localStorage.getItem("brahma_echo_settings") || "null");
      if (!raw) return "Neutral";
      const tags = [];
      if (raw.seriousPlayful > 35) tags.push("Playful");
      else if (raw.seriousPlayful < -35) tags.push("Serious");
      if (raw.softBold > 35) tags.push("Bold");
      else if (raw.softBold < -35) tags.push("Soft");
      if (raw.abstractPractical > 35) tags.push("Practical");
      else if (raw.abstractPractical < -35) tags.push("Abstract");
      if (raw.passiveDirective > 35) tags.push("Directive");
      else if (raw.passiveDirective < -35) tags.push("Passive");
      return tags.length ? tags.join(" • ") : "Balanced";
    } catch {
      return "Neutral";
    }
  }, []);

  const handleScopeToggle = (key) =>
    setScope((prev) => ({ ...prev, [key]: !prev[key] }));

  // Export/Wipe helpers
  const exportAll = () => {
    const bundle = {
      exportedAt: new Date().toISOString(),
      memoryEnabled,
      memoryMode,
      memoryDuration,
      scope,
      echo: safeParse(localStorage.getItem("brahma_echo_settings")),
      wisdom: safeParse(localStorage.getItem("brahma_wisdom_state_v1")),
      rl: safeParse(localStorage.getItem("brahma_rl_experience_v1")),
      reflections: safeParse(localStorage.getItem("brahma-quick-reflections")) || [],
      conversations: safeParse(localStorage.getItem("brahma-conversations")) || [],
      simulations: safeParse(localStorage.getItem("brahma-simulations")) || [],
      history: safeParse(localStorage.getItem("brahma-history")) || [], // if you used this key earlier
    };
    const blob = new Blob([JSON.stringify(bundle, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `brahma-settings-and-memory-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast("Exported settings & memory");
  };

  const importAll = async () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "application/json";
    input.onchange = async (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      try {
        const text = await file.text();
        const data = JSON.parse(text);

        // Restore toggles
        if (typeof data.memoryEnabled === "boolean") setMemoryEnabled(data.memoryEnabled);
        if (typeof data.memoryMode === "string") setMemoryMode(data.memoryMode);
        if (typeof data.memoryDuration === "string") setMemoryDuration(data.memoryDuration);
        if (data.scope && typeof data.scope === "object") setScope(data.scope);

        // Restore stores
        safeSet("brahma_echo_settings", data.echo);
        safeSet("brahma_wisdom_state_v1", data.wisdom);
        safeSet("brahma_rl_experience_v1", data.rl);
        safeSet("brahma-quick-reflections", data.reflections);
        safeSet("brahma-conversations", data.conversations);
        safeSet("brahma-simulations", data.simulations);
        safeSet("brahma-history", data.history);

        toast("Imported settings & memory");
      } catch {
        toast("Import failed");
      }
    };
    input.click();
  };

  const wipeAll = () => {
    const ok = window.confirm(
      "Erase all local memory, reflections, conversations, and RL logs? This cannot be undone."
    );
    if (!ok) return;

    [
      "brahma_echo_settings",
      "brahma_wisdom_state_v1",
      "brahma_rl_experience_v1",
      "brahma-quick-reflections",
      "brahma-conversations",
      "brahma-simulations",
      "brahma-history",
    ].forEach((k) => localStorage.removeItem(k));

    toast("All local memory wiped");
  };

  const toast = (msg) => {
    const d = document.createElement("div");
    d.className =
      "fixed top-4 left-1/2 -translate-x-1/2 bg-emerald-600 text-white px-4 py-2 rounded-lg z-[999] shadow-lg";
    d.textContent = msg;
    document.body.appendChild(d);
    setTimeout(() => d.remove(), 1400);
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      {/* Panel */}
      <div className="relative bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl shadow-2xl w-full max-w-5xl max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-white/10 bg-gradient-to-r from-purple-600/20 to-pink-600/20">
          <div className="flex items-center gap-3">
            <Cog className="w-5 h-5 text-purple-300" />
            <div>
              <h2 className="text-white font-semibold">Settings</h2>
              <p className="text-xs text-purple-200/80">
                Personalize your experience. All preferences are stored locally.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-white/10 text-gray-300"
            aria-label="Close settings"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="px-4 pt-3 border-b border-white/10 overflow-x-auto no-scrollbar">
          <div className="flex gap-2 min-w-max">
            <TabButton
              icon={Cog}
              label="General"
              active={activeTab === "general"}
              onClick={() => setActiveTab("general")}
            />
            <TabButton
              icon={Monitor}
              label="Display"
              active={activeTab === "display"}
              onClick={() => setActiveTab("display")}
            />
            <TabButton
              icon={SlidersHorizontal}
              label="Voice & Echo"
              active={activeTab === "voice"}
              onClick={() => setActiveTab("voice")}
            />
            <TabButton
              icon={Database}
              label="Memory"
              active={activeTab === "memory"}
              onClick={() => setActiveTab("memory")}
            />
          </div>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto max-h-[70vh]">
          {activeTab === "general" && (
            <GeneralTab userData={userData} />
          )}

          {activeTab === "display" && (
            <DisplayTab
              showParticles={showParticles}
              setShowParticles={setShowParticles}
              showAvatar={showAvatar}
              setShowAvatar={setShowAvatar}
              reducedMotion={reducedMotion}
              setReducedMotion={setReducedMotion}
            />
          )}

          {activeTab === "voice" && (
            <VoiceEchoTab
              echoSummary={echoSummary}
              onOpenEcho={() => setShowEcho(true)}
              onOpenVoice={() => setShowVoice(true)}
            />
          )}

          {activeTab === "memory" && (
            <MemoryTab
              memoryEnabled={memoryEnabled}
              setMemoryEnabled={setMemoryEnabled}
              memoryMode={memoryMode}
              setMemoryMode={setMemoryMode}
              memoryDuration={memoryDuration}
              setMemoryDuration={setMemoryDuration}
              scope={scope}
              onScopeToggle={handleScopeToggle}
              onExport={exportAll}
              onImport={importAll}
              onWipe={wipeAll}
            />
          )}
        </div>

        {/* Footer tagline */}
        <div className="px-6 py-3 border-t border-white/10">
          <div className="text-xs text-purple-300 italic">
            Governed by the Wisdom Integration Layer • RL signals logged locally • You own your evolution
          </div>
        </div>
      </div>

      {/* Sub-modals */}
      {showEcho && (
        <EchoSettings
          isOpen={showEcho}
          onClose={() => setShowEcho(false)}
          onApply={() => setShowEcho(false)}
        />
      )}
      {showVoice && (
        <VoiceModulator
          isOpen={showVoice}
          onClose={() => setShowVoice(false)}
          onApply={() => setShowVoice(false)}
        />
      )}
    </div>
  );
};

/* ---------------- Subcomponents ---------------- */

function TabButton({ icon: Icon, label, active, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition ${
        active ? "bg-white/15 text-white" : "text-purple-200 hover:bg-white/10"
      }`}
    >
      <Icon className="w-4 h-4" />
      {label}
    </button>
  );
}

function GeneralTab({ userData }) {
  return (
    <div className="space-y-4">
      <SectionTitle icon={Info} title="About" />
      <div className="bg-white/5 border border-white/10 rounded-xl p-4">
        <p className="text-sm text-gray-300">
          <span className="text-white font-medium">Brahma Transparency Engine</span> helps you make
          complex decisions with clarity, privacy, and dignity. Nothing leaves your device unless you export it.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="bg-white/5 border border-white/10 rounded-xl p-4">
          <div className="text-sm text-white mb-1">Your Guide</div>
          <div className="text-xs text-gray-400">
            {userData?.sage?.name || "Sage"} adapts tone and pacing to your preferences over time.
          </div>
        </div>
        <div className="bg-white/5 border border-white/10 rounded-xl p-4">
          <div className="text-sm text-white mb-1">Privacy</div>
          <div className="text-xs text-gray-400">
            Lifetime Privacy Contract, Data Shadow, and Wisdom Memory are fully optional and local-first.
          </div>
        </div>
      </div>
    </div>
  );
}

function DisplayTab({
  showParticles,
  setShowParticles,
  showAvatar,
  setShowAvatar,
  reducedMotion,
  setReducedMotion,
}) {
  return (
    <div className="space-y-4">
      <SectionTitle icon={Monitor} title="Display & Accessibility" />
      <div className="grid md:grid-cols-2 gap-4">
        <ToggleRow
          label="Ambient particles"
          description="Soft animated background lights."
          checked={showParticles}
          onChange={setShowParticles}
        />
        <ToggleRow
          label="Floating avatar"
          description="Show guide's avatar on the screen."
          checked={showAvatar}
          onChange={setShowAvatar}
        />
        <ToggleRow
          label="Reduced motion"
          description="Minimize animations for comfort."
          checked={reducedMotion}
          onChange={setReducedMotion}
        />
      </div>
    </div>
  );
}

function VoiceEchoTab({ echoSummary, onOpenEcho, onOpenVoice }) {
  return (
    <div className="space-y-4">
      <SectionTitle icon={SlidersHorizontal} title="Voice & Echo" />
      <div className="grid md:grid-cols-2 gap-4">
        <div className="bg-white/5 border border-white/10 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-white">Echo Personality</div>
              <div className="text-xs text-gray-400">
                Current blend: <span className="text-purple-200">{echoSummary}</span>
              </div>
            </div>
            <button
              onClick={onOpenEcho}
              className="px-3 py-2 rounded-lg text-xs bg-white/10 hover:bg-white/20 border border-white/20 text-white"
            >
              Open Echo Settings
            </button>
          </div>
          <div className="text-[11px] text-gray-400 mt-2">
            Adjust tone across playful/serious, soft/bold, abstract/practical, passive/directive.
          </div>
        </div>

        <div className="bg-white/5 border border-white/10 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-white">Voice Modulator</div>
              <div className="text-xs text-gray-400">
                Choose voice, pacing, and tone filters for TTS playback.
              </div>
            </div>
            <button
              onClick={onOpenVoice}
              className="px-3 py-2 rounded-lg text-xs bg-white/10 hover:bg-white/20 border border-white/20 text-white"
            >
              Open Voice Modulator
            </button>
          </div>
          <div className="text-[11px] text-gray-400 mt-2">
            Works with Translate & Listen and Sage narration.
          </div>
        </div>
      </div>
    </div>
  );
}

function MemoryTab({
  memoryEnabled,
  setMemoryEnabled,
  memoryMode,
  setMemoryMode,
  memoryDuration,
  setMemoryDuration,
  scope,
  onScopeToggle,
  onExport,
  onImport,
  onWipe,
}) {
  return (
    <div className="space-y-5">
      <SectionTitle icon={Database} title="Memory (Local)" />

      {/* Enable */}
      <ToggleRow
        label="Enable local memory"
        description="Allow saving reflections, outcomes, and context on this device."
        checked={memoryEnabled}
        onChange={setMemoryEnabled}
      />

      {/* Mode */}
      <div className="bg-white/5 border border-white/10 rounded-xl p-4">
        <div className="text-sm text-white mb-2">Wisdom Memory Mode</div>
        <div className="grid md:grid-cols-2 gap-2">
          <RadioPill
            checked={memoryMode === "off"}
            onChange={() => setMemoryMode("off")}
            title="Off"
            desc="No memory saved."
          />
          <RadioPill
            checked={memoryMode === "contextual"}
            onChange={() => setMemoryMode("contextual")}
            title="Contextual Only"
            desc="Light context to make sessions smoother."
          />
          <RadioPill
            checked={memoryMode === "insight"}
            onChange={() => setMemoryMode("insight")}
            title="Emotional + Insight"
            desc="Track feelings & evolving insights."
          />
          <RadioPill
            checked={memoryMode === "full"}
            onChange={() => setMemoryMode("full")}
            title="Full Relational Recall"
            desc="Rich memory across decisions & outcomes."
          />
        </div>
      </div>

      {/* Retention */}
      <div className="bg-white/5 border border-white/10 rounded-xl p-4">
        <div className="text-sm text-white mb-2">Retention Duration</div>
        <select
          value={memoryDuration}
          onChange={(e) => setMemoryDuration(e.target.value)}
          className="w-full bg-white/10 text-white px-3 py-2 rounded-lg text-sm border border-white/20 focus:outline-none"
          disabled={!memoryEnabled}
        >
          <option value="7" className="bg-gray-900">1 week</option>
          <option value="30" className="bg-gray-900">1 month</option>
          <option value="90" className="bg-gray-900">3 months</option>
          <option value="365" className="bg-gray-900">1 year</option>
          <option value="forever" className="bg-gray-900">Forever (locally)</option>
        </select>
      </div>

      {/* Scope */}
      <div className="bg-white/5 border border-white/10 rounded-xl p-4">
        <div className="text-sm text-white mb-3">Scope</div>
        <div className="grid md:grid-cols-2 gap-2">
          <CheckRow
            label="Store Reflection Logs"
            checked={scope.reflections}
            onChange={() => onScopeToggle("reflections")}
            helper="Quick reflections / Whisper panel"
          />
          <CheckRow
            label="Store Decisions & Outcomes"
            checked={scope.decisions}
            onChange={() => onScopeToggle("decisions")}
            helper="Decision options, scenarios, results"
          />
          <CheckRow
            label="Store Emotional Transitions"
            checked={scope.emotions}
            onChange={() => onScopeToggle("emotions")}
            helper="Mood tags, transitions over time"
          />
          <CheckRow
            label="Store Sage Conversations"
            checked={scope.conversations}
            onChange={() => onScopeToggle("conversations")}
            helper="Chat logs for continuity"
          />
        </div>
      </div>

      {/* Export / Import / Wipe */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={onExport}
          className="px-3 py-2 rounded-lg text-xs bg-white/10 hover:bg-white/20 border border-white/20 text-white flex items-center gap-2"
        >
          <Download className="w-3.5 h-3.5" />
          Export All
        </button>
        <button
          onClick={onImport}
          className="px-3 py-2 rounded-lg text-xs bg-white/10 hover:bg-white/20 border border-white/20 text-white flex items-center gap-2"
        >
          <Upload className="w-3.5 h-3.5" />
          Import
        </button>
        <button
          onClick={onWipe}
          className="px-3 py-2 rounded-lg text-xs bg-red-600/20 hover:bg-red-600/30 border border-red-500/30 text-red-300 flex items-center gap-2"
        >
          <Trash2 className="w-3.5 h-3.5" />
          Wipe All
        </button>
      </div>

      <div className="flex items-start gap-2 text-xs text-gray-400">
        <AlertTriangle className="w-4 h-4 mt-0.5 text-yellow-300" />
        <span>
          All memory is stored locally on this device. Wipe removes local data only and does not affect any cloud backups you may export manually.
        </span>
      </div>
    </div>
  );
}

/* --- Reusable small pieces --- */

function SectionTitle({ icon: Icon, title }) {
  return (
    <div className="flex items-center gap-2 mb-1">
      <Icon className="w-4 h-4 text-purple-300" />
      <div className="text-sm text-white">{title}</div>
    </div>
  );
}

function ToggleRow({ label, description, checked, onChange }) {
  return (
    <div className="flex items-center justify-between bg-white/5 border border-white/10 rounded-xl p-4">
      <div>
        <div className="text-sm text-white">{label}</div>
        {description && <div className="text-xs text-gray-400">{description}</div>}
      </div>
      <label className="relative inline-flex items-center cursor-pointer">
        <input
          type="checkbox"
          className="sr-only peer"
          checked={!!checked}
          onChange={(e) => onChange?.(e.target.checked)}
        />
        <div className="w-10 h-5 bg-gray-600 rounded-full peer peer-checked:bg-purple-600 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:h-4 after:w-4 after:rounded-full after:transition-all peer-checked:after:translate-x-5" />
      </label>
    </div>
  );
}

function RadioPill({ checked, onChange, title, desc }) {
  return (
    <label
      className={`p-3 rounded-xl border transition cursor-pointer ${
        checked ? "bg-white/15 border-white/30" : "bg-white/5 border-white/10 hover:bg-white/10"
      }`}
    >
      <div className="flex items-start gap-3">
        <input
          type="radio"
          className="mt-1 accent-purple-500"
          checked={checked}
          onChange={onChange}
        />
        <div>
          <div className="text-sm text-white">{title}</div>
          <div className="text-xs text-gray-400">{desc}</div>
        </div>
      </div>
    </label>
  );
}

function CheckRow({ label, checked, onChange, helper }) {
  return (
    <label className="flex items-start gap-3 bg-white/5 border border-white/10 rounded-xl p-3 cursor-pointer hover:bg-white/10 transition">
      <input type="checkbox" className="mt-0.5 accent-purple-500" checked={!!checked} onChange={onChange} />
      <div>
        <div className="text-sm text-white">{label}</div>
        {helper && <div className="text-xs text-gray-400">{helper}</div>}
      </div>
    </label>
  );
}

/* --- Utils --- */
function safeParse(str) {
  try {
    return JSON.parse(str || "null");
  } catch {
    return null;
  }
}
function safeSet(key, val) {
  try {
    if (val === undefined) return;
    localStorage.setItem(key, JSON.stringify(val));
  } catch {}
}

export default SettingsPanel;
