// src/components/transparency/SageChat.jsx
import React, { useEffect, useRef, useState } from "react";

/**
 * Props:
 * - conversations: Array<{ user: string, sage: string }>
 * - onSendMessage: (message: string) => void
 * - isTyping?: boolean
 * - userData?: any
 * - settings?: { reducedMotion?: boolean }
 * - onRegenerate?: (lastUserMessage: string) => void   // optional
 * - onFeedback?: (payload: { index: number, role: 'sage'|'user', value: 'like'|'dislike' }) => void // optional
 */
const SageChat = ({
  conversations = [],
  onSendMessage,
  isTyping = false,
  userData,
  settings,
  onRegenerate,
  onFeedback,
}) => {
  const [input, setInput] = useState("");
  const [reactions, setReactions] = useState({});
  const scrollRef = useRef(null);
  const endRef = useRef(null);

  // scroll helpers state
  const [showTop, setShowTop] = useState(false);
  const [showBottom, setShowBottom] = useState(false);

  // Auto-scroll to bottom when new content arrives (unless user has scrolled far up)
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;

    const nearBottom =
      el.scrollHeight - el.scrollTop - el.clientHeight < 120;

    if (nearBottom || settings?.reducedMotion) {
      // Jump to bottom
      el.scrollTo({ top: el.scrollHeight, behavior: settings?.reducedMotion ? "auto" : "smooth" });
    }
  }, [conversations, isTyping, settings?.reducedMotion]);

  // Track scroll position to show/hide arrows
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;

    const handleScroll = () => {
      const atTop = el.scrollTop <= 8;
      const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight <= 8;
      setShowTop(!atTop);
      setShowBottom(!atBottom);
    };

    handleScroll();
    el.addEventListener("scroll", handleScroll, { passive: true });
    return () => el.removeEventListener("scroll", handleScroll);
  }, []);

  // ---------- utilities ----------
  const toast = (msg) => {
    const d = document.createElement("div");
    d.className =
      "fixed top-4 left-1/2 -translate-x-1/2 bg-black/80 text-white border border-white/20 px-3 py-1.5 rounded-lg text-xs z-50";
    d.textContent = msg;
    document.body.appendChild(d);
    setTimeout(() => d.remove(), 1200);
  };

  const copyToClipboard = async (text) => {
    try {
      await navigator.clipboard.writeText(text || "");
      toast("Copied to clipboard");
    } catch {
      toast("Copy failed");
    }
  };

  const speak = (text) => {
    try {
      if (!text) return;
      window.speechSynthesis.cancel();
      const utter = new SpeechSynthesisUtterance(text);
      utter.rate = 1;
      utter.pitch = 1;
      utter.lang = "en-US";
      window.speechSynthesis.speak(utter);
    } catch {
      toast("Text-to-speech not available");
    }
  };

  const stopSpeaking = () => {
    try {
      window.speechSynthesis.cancel();
    } catch {}
  };

  useEffect(() => () => stopSpeaking(), []); // stop on unmount

  const exportMarkdown = () => {
    const title = `Brahma Chat ${new Date().toLocaleString()}`;
    const lines = [`# ${title}`, ""];
    conversations.forEach((m, i) => {
      if (m.user) lines.push(`**You:** ${m.user}`);
      if (m.sage) lines.push(`**${userData?.sage?.name || "Sage"}:** ${m.sage}`);
      if (i < conversations.length - 1) lines.push("");
    });
    downloadFile(lines.join("\n"), `brahma-chat-${Date.now()}.md`, "text/markdown");
  };

  const exportJSON = () => {
    const payload = {
      title: `Brahma Chat`,
      createdAt: new Date().toISOString(),
      messages: conversations,
      sage: userData?.sage || { name: "Sage" },
    };
    downloadFile(JSON.stringify(payload, null, 2), `brahma-chat-${Date.now()}.json`, "application/json");
  };

  const downloadFile = (content, filename, type) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    toast("Export ready");
  };

  const handleSend = () => {
    const text = input.trim();
    if (!text) return;
    stopSpeaking();
    onSendMessage?.(text);
    setInput("");
  };

  const handleRegenerate = () => {
    stopSpeaking();
    const lastUser = [...conversations].reverse().find((m) => m.user)?.user || input.trim();
    if (!lastUser) return toast("Nothing to regenerate");
    if (onRegenerate) onRegenerate(lastUser);
    else onSendMessage?.(lastUser);
  };

  const setReaction = (key, value) => {
    setReactions((p) => ({ ...p, [key]: p[key] === value ? undefined : value }));
  };

  const scrollToTop = () => {
    scrollRef.current?.scrollTo({ top: 0, behavior: settings?.reducedMotion ? "auto" : "smooth" });
  };
  const scrollToBottom = () => {
    const el = scrollRef.current;
    if (!el) return;
    el.scrollTo({ top: el.scrollHeight, behavior: settings?.reducedMotion ? "auto" : "smooth" });
  };

  // ---------- UI ----------
  return (
    <div className="flex flex-col h-[560px] relative">
      {/* Top actions */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-white/10 bg-gradient-to-r from-purple-600/10 to-pink-600/10">
        <div className="text-xs text-gray-300">
          {userData?.sage?.name || "Sage"} is privacy-first • Local only
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleRegenerate}
            className="px-2.5 py-1.5 text-xs rounded-md bg-white/10 hover:bg-white/20 border border-white/20"
            title="Regenerate last answer"
          >
            ↻ Regenerate
          </button>
          <div className="h-4 w-px bg-white/20" />
          <button
            onClick={exportMarkdown}
            className="px-2.5 py-1.5 text-xs rounded-md bg-white/10 hover:bg-white/20 border border-white/20"
            title="Export as Markdown"
          >
            ⤓ Export .md
          </button>
          <button
            onClick={exportJSON}
            className="px-2.5 py-1.5 text-xs rounded-md bg-white/10 hover:bg-white/20 border border-white/20"
            title="Export as JSON"
          >
            ⤓ Export .json
          </button>
        </div>
      </div>

      {/* Messages (scroll container) */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 space-y-4 scroll-smooth"
      >
        {conversations.length === 0 && (
          <div className="text-center text-sm text-gray-400 py-16">
            Start a conversation—your decisions stay yours. Your wisdom stays local.
          </div>
        )}

        {conversations.map((m, idx) => (
          <div key={idx} className="space-y-2">
            {m.user?.trim() ? (
              <div className="flex justify-end">
                <div className="max-w-[80%] bg-blue-500/20 border border-blue-400/30 rounded-xl px-3 py-2 text-sm text-blue-100">
                  {m.user}
                </div>
              </div>
            ) : null}

            {m.sage?.trim() ? (
              <div className="group flex items-start gap-2">
                <div className="h-8 w-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white text-xs shrink-0">
                  {(userData?.sage?.name || "S")[0]}
                </div>
                <div className="relative max-w-[82%] bg-white/5 border border-white/10 rounded-xl px-3 py-2">
                  <div className="prose prose-invert prose-sm max-w-none text-gray-100">
                    {m.sage}
                  </div>

                  <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-2 right-2 flex items-center gap-1">
                    <button
                      onClick={() => copyToClipboard(m.sage)}
                      className="px-2 py-1 text-[11px] rounded bg-white/10 hover:bg-white/20 border border-white/20"
                      title="Copy"
                    >
                      ⧉
                    </button>
                    <button
                      onClick={() => speak(m.sage)}
                      className="px-2 py-1 text-[11px] rounded bg-white/10 hover:bg-white/20 border border-white/20"
                      title="Text-to-Speech"
                    >
                      🔊
                    </button>
                    <button
                      onClick={stopSpeaking}
                      className="px-2 py-1 text-[11px] rounded bg-white/10 hover:bg-white/20 border border-white/20"
                      title="Stop speech"
                    >
                      ⏹
                    </button>
                    <div className="h-3 w-px bg-white/20 mx-1" />
                    <button
                      onClick={() => {
                        setReaction(`${idx}-sage`, "like");
                        onFeedback?.({ index: idx, role: "sage", value: "like" });
                      }}
                      className={`px-2 py-1 text-[11px] rounded border ${
                        reactions[`${idx}-sage`] === "like"
                          ? "bg-emerald-600/70 border-emerald-400 text-white"
                          : "bg-white/10 hover:bg-white/20 border-white/20"
                      }`}
                      title="Like"
                    >
                      👍
                    </button>
                    <button
                      onClick={() => {
                        setReaction(`${idx}-sage`, "dislike");
                        onFeedback?.({ index: idx, role: "sage", value: "dislike" });
                      }}
                      className={`px-2 py-1 text-[11px] rounded border ${
                        reactions[`${idx}-sage`] === "dislike"
                          ? "bg-rose-600/70 border-rose-400 text-white"
                          : "bg-white/10 hover:bg-white/20 border-white/20"
                      }`}
                      title="Dislike"
                    >
                      👎
                    </button>
                  </div>
                </div>
              </div>
            ) : null}
          </div>
        ))}

        {isTyping && (
          <div className="flex items-center gap-2 text-gray-300 text-sm">
            <span className="inline-flex -space-x-1">
              <Dot /> <Dot delay="150ms" /> <Dot delay="300ms" />
            </span>
            {userData?.sage?.name || "Sage"} is thinking…
          </div>
        )}
        <div ref={endRef} />
      </div>

      {/* Scroll helpers (floating) */}
      {showTop && (
        <button
          onClick={scrollToTop}
          className="absolute right-4 top-16 z-20 bg-white/10 hover:bg-white/20 border border-white/20 backdrop-blur px-2.5 py-1.5 rounded-full text-xs"
          title="Scroll to top"
          aria-label="Scroll to top"
        >
          ⬆︎ Top
        </button>
      )}
      {showBottom && (
        <button
          onClick={scrollToBottom}
          className="absolute right-4 bottom-20 z-20 bg-white/10 hover:bg-white/20 border border-white/20 backdrop-blur px-2.5 py-1.5 rounded-full text-xs"
          title="Scroll to bottom"
          aria-label="Scroll to bottom"
        >
          ⬇︎ Bottom
        </button>
      )}

      {/* Input */}
      <div className="p-4 border-t border-white/10">
        <div className="flex items-center gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Share what's on your mind…"
            className="flex-1 bg-white/10 text-white placeholder-gray-400 px-4 py-3 rounded-xl border border-white/20 focus:ring-2 focus:ring-purple-500 outline-none"
          />
          <button
            onClick={handleSend}
            className="px-4 py-3 rounded-xl bg-purple-600 hover:bg-purple-700 text-white border border-white/20"
          >
            Send
          </button>
        </div>
      </div>
    </div>
  );
};

const Dot = ({ delay = "0ms" }) => (
  <span
    className="inline-block w-1.5 h-1.5 rounded-full bg-white/70 animate-bounce"
    style={{ animationDelay: delay }}
  />
);

export default SageChat;