
// /src/components/JournalModal.jsx
import React, { useState, useEffect } from 'react';

export default function JournalModal({ isOpen, onClose, onSaveEntry }) {
  const [entry, setEntry] = useState('');
  const [prompt, setPrompt] = useState('');

  useEffect(() => {
    if (isOpen) {
      const prompts = [
        "What stands out most as you reflect on these possibilities?",
        "How do these options align with what you want your life to look like?",
        "What themes are emerging in what draws you forward or holds you back?",
        "If you trusted your intuition completely, what would it be telling you?"
      ];
      setPrompt(prompts[Math.floor(Math.random() * prompts.length)]);
    }
  }, [isOpen]);

  const handleSave = () => {
    if (entry.trim()) {
      onSaveEntry({
        content: entry,
        prompt: prompt,
        timestamp: new Date().toISOString()
      });
      setEntry('');
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/20 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="glassmorphism rounded-xl p-6 max-w-lg w-full shadow-2xl slide-in">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-light text-gray-800">Reflection Space</h2>
          <button 
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 text-xl font-light hover:scale-110 transition-transform"
          >
            ×
          </button>
        </div>
        
        <div className="space-y-4">
          <div className="bg-purple-50 p-4 rounded-lg">
            <p className="text-sm text-gray-700 font-light italic">{prompt}</p>
          </div>
          
          <textarea
            value={entry}
            onChange={e => setEntry(e.target.value)}
            placeholder="Take your time... there's no right or wrong here."
            className="w-full h-32 p-4 border border-gray-300 rounded-lg bg-white/50 focus:ring-2 focus:ring-purple-300 focus:border-transparent resize-none"
          />
          
          <div className="flex justify-between">
            <button 
              onClick={onClose}
              className="text-sm text-gray-500 hover:text-gray-700"
            >
              Maybe later
            </button>
            <button 
              onClick={handleSave}
              disabled={!entry.trim()}
              className="px-6 py-2 bg-[#8E7BEF] text-white rounded-full hover:bg-purple-600 transition-colors shadow-md disabled:opacity-50"
            >
              Save Reflection
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
