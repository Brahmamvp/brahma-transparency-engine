import React, { useState } from "react";
import InteractiveSageAvatar from "../common/InteractiveSageAvatar.jsx";

/** Simple playground to verify avatar state & props. */
const AvatarShowcase = () => {
  const [currentMood, setCurrentMood] = useState("peaceful");
  const [currentForm, setCurrentForm] = useState("orb");
  const [isThinking, setIsThinking] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [size, setSize] = useState("large");

  const moods = ["peaceful", "curious", "thoughtful", "empathetic", "analytical", "excited"];
  const forms = ["orb", "geometric", "silhouette"];
  const sizes = ["small", "medium", "large", "xl"];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white">
      <div className="container mx-auto px-6 py-8 max-w-4xl">

        {/* Header */}
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent mb-2">
            Interactive Sage Avatar
          </h1>
          <p className="text-gray-300">Mood-responsive, form-changing, and fully interactive</p>
        </div>

        {/* Avatar Display */}
        <div className="text-center mb-10">
          <div className="flex justify-center mb-6">
            <InteractiveSageAvatar
              mood={currentMood}
              form={currentForm}
              size={size}
              isThinking={isThinking}
              isListening={isListening}
              conversationTone="demo"
              onAvatarClick={() => {
                // cycle mood on click to prove interactivity
                const i = moods.indexOf(currentMood);
                setCurrentMood(moods[(i + 1) % moods.length]);
              }}
            />
          </div>

          {/* live readout to confirm state updates */}
          <div className="text-xs text-purple-200/80">
            mood: <span className="font-semibold">{currentMood}</span> • form:{" "}
            <span className="font-semibold">{currentForm}</span> • size:{" "}
            <span className="font-semibold">{size}</span> • thinking:{" "}
            <span className="font-semibold">{String(isThinking)}</span> • listening:{" "}
            <span className="font-semibold">{String(isListening)}</span>
          </div>
        </div>

        {/* Controls */}
        <div className="space-y-8">

          {/* Mood */}
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
            <h3 className="text-lg font-semibold mb-4">Mood</h3>
            <div className="grid grid-cols-3 gap-3">
              {moods.map((m) => (
                <button
                  key={m}
                  onClick={() => setCurrentMood(m)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all capitalize ${
                    currentMood === m ? "bg-purple-600 text-white" : "bg-white/10 text-gray-300 hover:bg-white/20"
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>

          {/* Form */}
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
            <h3 className="text-lg font-semibold mb-4">Form</h3>
            <div className="grid grid-cols-3 gap-3">
              {forms.map((f) => (
                <button
                  key={f}
                  onClick={() => setCurrentForm(f)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all capitalize ${
                    currentForm === f ? "bg-blue-600 text-white" : "bg-white/10 text-gray-300 hover:bg-white/20"
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          {/* Size */}
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
            <h3 className="text-lg font-semibold mb-4">Size</h3>
            <div className="grid grid-cols-4 gap-3">
              {sizes.map((s) => (
                <button
                  key={s}
                  onClick={() => setSize(s)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all capitalize ${
                    size === s ? "bg-emerald-600 text-white" : "bg-white/10 text-gray-300 hover:bg-white/20"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* States */}
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
            <h3 className="text-lg font-semibold mb-4">States</h3>
            <div className="flex gap-4">
              <button
                onClick={() => setIsThinking((v) => !v)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  isThinking ? "bg-orange-600 text-white" : "bg-white/10 text-gray-300 hover:bg-white/20"
                }`}
              >
                {isThinking ? "Stop Thinking" : "Start Thinking"}
              </button>

              <button
                onClick={() => setIsListening((v) => !v)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  isListening ? "bg-red-600 text-white" : "bg-white/10 text-gray-300 hover:bg-white/20"
                }`}
              >
                {isListening ? "Stop Listening" : "Start Listening"}
              </button>
            </div>
          </div>
        </div>

        {/* Feature list */}
        <div className="mt-12 bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
          <h3 className="text-lg font-semibold mb-4">Avatar Features</h3>
          <ul className="space-y-2 text-gray-300">
            <li>✨ <strong>Mood-Responsive Colors</strong></li>
            <li>🔄 <strong>Dynamic Forms</strong> (orb, geometric, silhouette)</li>
            <li>💫 <strong>Thinking Particles</strong></li>
            <li>📡 <strong>Listening Indicator</strong></li>
            <li>🫁 <strong>Breathing Animation</strong></li>
            <li>🎯 <strong>Interactive</strong> (click cycles mood)</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default AvatarShowcase;