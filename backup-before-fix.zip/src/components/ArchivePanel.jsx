// /src/components/ArchivePanel.jsx
import React from 'react';

export default function ArchivePanel({ isOpen, onClose, archivedOptions, onRestoreOption }) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/20 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="glassmorphism rounded-xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto shadow-2xl slide-in">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-medium text-gray-800">Your Archive</h2>
          <button 
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 text-xl font-light"
          >
            ×
          </button>
        </div>
        
        {archivedOptions.length === 0 ? (
          <div className="text-center py-8">
            <div className="text-4xl mb-4">📚</div>
            <p className="text-gray-600">No archived options yet</p>
            <p className="text-sm text-gray-500 mt-2">Options you hide or archive will appear here for future reference.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {archivedOptions.map(option => (
              <div key={option.id} className="bg-white/30 p-4 rounded-lg border border-gray-200">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-medium text-gray-700">{option.title}</h3>
                    <p className="text-sm text-gray-600">{option.cost}</p>
                    <p className="text-sm text-gray-600 italic mt-1">{option.summary}</p>
                  </div>
                  <button
                    onClick={() => onRestoreOption(option)}
                    className="text-sm px-3 py-1 bg-purple-100 text-purple-700 rounded-full hover:bg-purple-200 transition-colors"
                  >
                    Restore
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
