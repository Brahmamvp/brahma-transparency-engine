
import React, { useState } from 'react';
import { storyBlocks, wisdomPatterns } from '../data/stories';

export default function ReflectionCard({ 
  option, 
  onPin, 
  onHide, 
  onAskSage, 
  isPinned, 
  isHidden, 
  assumptions,
  onRate,
  onExportToSilhouette
}) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [userRating, setUserRating] = useState(0);
  const [hasRated, setHasRated] = useState(false);
  
  if (isHidden) return null;

  // Story block matching user assumptions
  const getRelevantStory = () => {
    const userProfile = `${assumptions.riskTolerance}_${assumptions.timeline}`;
    const matchingStory = storyBlocks.find(story => 
      story.demographic.includes(assumptions.riskTolerance) || 
      story.demographic.includes(assumptions.timeline)
    );
    return matchingStory || storyBlocks[0];
  };

  const relevantStory = getRelevantStory();

  const handleRate = (rating) => {
    setUserRating(rating);
    setHasRated(true);
    if (onRate) {
      onRate(option.id, rating);
    }
  };

  const handleExportToSilhouette = () => {
    if (onExportToSilhouette) {
      onExportToSilhouette({
        optionTitle: option.title,
        userRating: userRating,
        expansion: isExpanded,
        story: relevantStory,
        timestamp: new Date().toISOString()
      });
    }
  };

  return (
    <div className="glassmorphism p-6 rounded-xl shadow-lg space-y-4 slide-in hover:shadow-xl transition-all group">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="text-lg font-medium text-gray-800">{option.title}</h3>
          <p className="text-sm text-gray-600 mt-1">{option.cost}</p>
        </div>
        <div className="flex gap-2 opacity-70 group-hover:opacity-100 transition-opacity">
          <button 
            onClick={() => onPin(option.id)}
            className={`text-lg hover:scale-110 transition-transform ${isPinned ? 'text-purple-600' : 'text-gray-400'}`}
            title={isPinned ? 'Unpin' : 'Pin for later'}
          >
            📌
          </button>
          <button 
            onClick={() => onHide(option.id)}
            className="text-lg text-gray-400 hover:text-gray-600 hover:scale-110 transition-all"
            title="Hide this option"
          >
            👁️‍🗨️
          </button>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs font-medium text-gray-500">RISK LEVEL</span>
          <div className={`px-3 py-1 rounded-full text-xs font-medium ${
            option.risk === 'High' ? 'bg-pink-100 text-pink-700' :
            option.risk === 'Medium' ? 'bg-yellow-100 text-yellow-700' :
            'bg-green-100 text-green-700'
          }`}>
            {option.risk}
          </div>
          <span className="text-xs text-gray-400 italic">This rating only reflects what's been seen in similar paths. Not a verdict.</span>
        </div>
        
        <p className="text-sm text-gray-700 italic">{option.summary}</p>

        {/* Rating System */}
        {!hasRated && (
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-500">How does this feel?</span>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map(rating => (
                <button
                  key={rating}
                  onClick={() => handleRate(rating)}
                  className="text-lg hover:scale-110 transition-transform text-gray-300 hover:text-purple-400"
                >
                  ⭐
                </button>
              ))}
            </div>
          </div>
        )}

        {hasRated && (
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-500">Your feeling:</span>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map(rating => (
                <span
                  key={rating}
                  className={`text-sm ${rating <= userRating ? 'text-purple-500' : 'text-gray-300'}`}
                >
                  ⭐
                </span>
              ))}
            </div>
            <span className="text-xs text-purple-600 italic">
              {userRating >= 4 ? 'This resonates' : userRating >= 3 ? 'Interesting possibility' : 'Worth considering'}
            </span>
          </div>
        )}
        
        {isExpanded && (
          <div className="space-y-4 pt-3 border-t border-gray-200 fade-in">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium text-gray-600">Time Commitment:</span>
                <p className="text-gray-700">{option.details.timeCommitment}</p>
              </div>
              <div>
                <span className="font-medium text-gray-600">Success Rate:</span>
                <p className="text-gray-700">{option.details.successRate}</p>
              </div>
            </div>
            <div>
              <span className="font-medium text-gray-600">Worth Considering:</span>
              <p className="text-gray-700 text-sm">{option.details.considerations}</p>
            </div>

            {/* Enhanced Real Story Block */}
            <div className="bg-white/40 p-4 rounded-lg border-l-4 border-purple-200">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-xs font-medium text-gray-500">REAL STORY</h4>
                <span className="text-xs text-purple-600">Similar to you</span>
              </div>
              <p className="text-sm text-gray-700 italic mb-2">"{relevantStory.story}"</p>
              <div className="text-xs text-gray-500 space-y-1">
                <p className="font-medium">{relevantStory.outcome}</p>
                <p>Timeline: {relevantStory.timeframe}</p>
              </div>
            </div>

            {/* Federated Wisdom Pattern */}
            <div className="bg-gradient-to-r from-teal-50 to-purple-50 p-3 rounded-lg">
              <h4 className="text-xs font-medium text-gray-600 mb-1">PATTERN INSIGHT</h4>
              <p className="text-xs text-gray-700">
                {wisdomPatterns.education?.bootcamp || "Peer connections and structured support systems tend to increase completion rates significantly."}
              </p>
            </div>

            {/* Export to Growth Journey */}
            {hasRated && userRating >= 3 && (
              <div className="bg-purple-50 p-3 rounded-lg border border-purple-200">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-sm font-medium text-purple-700">Meaningful option?</span>
                    <p className="text-xs text-purple-600">Save this exploration to your growth journey</p>
                  </div>
                  <button
                    onClick={handleExportToSilhouette}
                    className="px-3 py-1 bg-purple-600 text-white text-xs rounded-full hover:bg-purple-700 transition-colors"
                  >
                    Save to Journey
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="flex flex-wrap gap-2 pt-2">
        <button 
          onClick={() => onAskSage(option)}
          className="text-sm px-4 py-2 bg-[#8E7BEF] text-white rounded-full hover:bg-purple-600 transition-colors shadow-md"
        >
          Ask Sage About This
        </button>
        <button 
          onClick={() => setIsExpanded(!isExpanded)}
          className="text-sm px-4 py-2 border border-gray-300 rounded-full hover:bg-white/50 transition-colors"
        >
          {isExpanded ? 'Show Less' : 'Explore Details'}
        </button>
        
        <button 
          className="text-sm px-4 py-2 text-gray-500 hover:text-gray-700 hover:underline transition-colors"
        >
          🗃️ Archive
        </button>
      </div>
    </div>
  );
}
