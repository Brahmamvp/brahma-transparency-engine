import React, { useState } from 'react';

const LifetimePrivacyContract = ({ onActivate, onClose }) => {
  const [signature, setSignature] = useState('');
  const [isActivating, setIsActivating] = useState(false);
  const [hasRead, setHasRead] = useState(false);

  const handleActivate = () => {
    if (!signature.trim()) return;
    setIsActivating(true);
    setTimeout(() => {
      onActivate({ signature: signature.trim(), timestamp: new Date().toISOString(), contractVersion: '1.0' });
      setIsActivating(false);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-white/20 shadow-2xl">
        <div className="text-center mb-6">
          <div className="text-3xl mb-3">🔒</div>
          <h2 className="text-2xl font-bold text-white mb-2">Lifetime Privacy Contract</h2>
          <p className="text-gray-300 text-sm">Your data sovereignty, permanently protected</p>
        </div>

        <div className="space-y-6 mb-8">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
            <h3 className="text-lg font-semibold text-white mb-4">Welcome to Brahma.</h3>
            <p className="text-gray-200 mb-4">We believe your data is your own — not a product, not a training set, not a commodity.</p>
            <div className="space-y-4 text-gray-200">
              <div>
                <h4 className="font-semibold text-white mb-2">By activating Lifetime Privacy Mode:</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2"><span className="text-emerald-400 mt-1">•</span><span>Keep your data local to your device</span></li>
                  <li className="flex items-start gap-2"><span className="text-emerald-400 mt-1">•</span><span>Prevent AI training on your data</span></li>
                  <li className="flex items-start gap-2"><span className="text-emerald-400 mt-1">•</span><span>No third-party sharing</span></li>
                </ul>
              </div>
              <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-lg p-4">
                <p className="text-white font-medium">Your privacy is your right.</p>
              </div>
            </div>
          </div>

          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
            <div className="flex items-start gap-3 mb-4">
              <input type="checkbox" id="privacy-agreement" checked={hasRead} onChange={(e) => setHasRead(e.target.checked)} className="mt-1 w-4 h-4" />
              <label htmlFor="privacy-agreement" className="text-sm text-gray-200 cursor-pointer">I agree to this Lifetime Privacy Contract</label>
            </div>
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-200">Signature:</label>
              <input
                type="text"
                value={signature}
                onChange={(e) => setSignature(e.target.value)}
                placeholder="Type your name to confirm"
                disabled={!hasRead}
                className="w-full bg-white/10 backdrop-blur-sm text-white placeholder-gray-400 px-4 py-3 rounded-xl border border-white/20 focus:outline-none focus:ring-2 focus:ring-purple-500 disabled:opacity-50"
              />
            </div>
          </div>
        </div>

        <div className="flex gap-4">
          <button
            onClick={handleActivate}
            disabled={!hasRead || !signature.trim() || isActivating}
            className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:opacity-50 disabled:cursor-not-allowed px-6 py-3 rounded-xl text-white font-medium transition-all flex items-center justify-center gap-2"
          >
            {isActivating ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                <span>Activating...</span>
              </>
            ) : (
              <>
                <span>🔒</span>
                <span>Activate Privacy Mode</span>
              </>
            )}
          </button>
          <button onClick={onClose} className="px-6 py-3 text-gray-400 hover:text-white transition-colors">Maybe Later</button>
        </div>
      </div>
    </div>
  );
};
export default LifetimePrivacyContract;
