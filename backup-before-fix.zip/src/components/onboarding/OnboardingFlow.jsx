import React, { useState } from 'react';
import SageIntro from './SageIntro.jsx';
import SageNamingRitual from './SageNamingRitual.jsx';
import OnboardingStatus from './OnboardingStatus.jsx'

const OnboardingFlow = ({ onComplete }) => {
  const [stage, setStage] = useState('intro');
  const [namingChoice, setNamingChoice] = useState(null);
  const [sageData, setSageData] = useState(null);

  const handleIntroComplete = (choice) => {
    setNamingChoice(choice);
    setStage('naming');
  };

  const handleNamingComplete = (data) => {
    setSageData(data);
    setStage('status');
  };

  const handleStatusComplete = (profileData) => {
    onComplete({ sage: sageData, profile: profileData });
  };

  return (
    <>
      {stage === 'intro' && <SageIntro onComplete={handleIntroComplete} />}
      {stage === 'naming' && <SageNamingRitual onComplete={handleNamingComplete} namingChoice={namingChoice} />}
      {stage === 'status' && <OnboardingStatus onComplete={handleStatusComplete} sageData={sageData} />}
    </>
  );
};

export default OnboardingFlow;