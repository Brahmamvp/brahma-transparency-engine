// /src/components/EditPanel.jsx
import React from 'react';
import { useUserPreferences } from '../context/UserPreferencesContext';

export default function EditPanel({ isOpen, onClose }) {
  const { assumptions, setAssumptions, lensSettings, setLensSettings } = useUserPreferences();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/20 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="glassmorphism rounded-xl p-6 max-w-md w-full max-h-[80vh] overflow-y-auto shadow-2xl slide-in">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-medium text-gray-800">Adjust Your Lens</h2>
          <button 
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 text-xl font-light hover:scale-110 transition-transform"
          >
            ×
          </button>
        </div>
        
        <div className="space-y-6">
          <div>
            <h3 className="font-medium text-gray-700 mb-3">Personal Assumptions</h3>
            <p className="text-xs text-gray-500 mb-4 italic">These help Sage understand your perspective — you can change them anytime.</p>
            <div className="space-y-3">
              <div>
                <label className="block text-sm text-gray-600 mb-1">Risk Tolerance</label>
                <select 
                  value={assumptions.riskTolerance}
                  onChange={e => setAssumptions({...assumptions, riskTolerance: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded-lg bg-white/50 focus:ring-2 focus:ring-purple-300 focus:border-transparent"
                >
                  <option value="conservative">Conservative - Prefer stability</option>
                  <option value="moderate">Moderate - Balanced approach</option>
                  <option value="adventurous">Adventurous - Open to bold moves</option>
                </select>
              </div>
              <div>
                <label className="block text-sm text-gray-600 mb-1">Timeline Preference</label>
                <select 
                  value={assumptions.timeline}
                  onChange={e => setAssumptions({...assumptions, timeline: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded-lg bg-white/50 focus:ring-2 focus:ring-purple-300 focus:border-transparent"
                >
                  <option value="immediate">Need results quickly</option>
                  <option value="flexible">Flexible timeline</option>
                  <option value="longterm">Thinking long-term</option>
                </select>
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-medium text-gray-700 mb-3">Exploration Lenses</h3>
            <p className="text-xs text-gray-500 mb-4 italic">Choose which perspectives feel most relevant to you right now.</p>
            <div className="space-y-3">
              {Object.entries(lensSettings).map(([lens, enabled]) => (
                <label key={lens} className="flex items-center gap-3 p-2 rounded-lg hover:bg-white/30 transition-colors">
                  <input
                    type="checkbox"
                    checked={enabled}
                    onChange={e => setLensSettings({...lensSettings, [lens]: e.target.checked})}
                    className="rounded text-purple-600 focus:ring-purple-300"
                  />
                  <div>
                    <span className="text-sm text-gray-700 font-medium capitalize">
                      {lens.replace(/([A-Z])/g, ' $1')}
                    </span>
                    <p className="text-xs text-gray-500">
                      {lens === 'financial' && 'Cost, income, and investment perspectives'}
                      {lens === 'emotional' && 'How choices align with your values and feelings'}
                      {lens === 'lifestyle' && 'Day-to-day life and routine considerations'}
                      {lens === 'familyImpact' && 'Effects on relationships and family dynamics'}
                      {lens === 'careerGrowth' && 'Long-term professional development'}
                    </p>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Enhanced Legacy Echo Preview */}
          <div className="border-t pt-6 border-gray-200">
            <h3 className="font-medium text-gray-700 mb-3">Future Vision</h3>
            <div className="space-y-3">
              <label className="flex items-center gap-3 p-3 rounded-lg hover:bg-white/30 transition-colors">
                <input
                  type="checkbox"
                  className="rounded text-purple-600 focus:ring-purple-300"
                />
                <div>
                  <span className="text-sm text-gray-700 font-medium">Visualize Long-term Impact</span>
                  <p className="text-xs text-gray-500">Preview how this decision might shape your story over time</p>
                </div>
              </label>
              
              <label className="flex items-center gap-3 p-3 rounded-lg hover:bg-white/30 transition-colors">
                <input
                  type="checkbox"
                  className="rounded text-purple-600 focus:ring-purple-300"
                />
                <div>
                  <span className="text-sm text-gray-700 font-medium">Decision Timeline Tracker</span>
                  <p className="text-xs text-gray-500">Keep a gentle log of your decision journey over time</p>
                </div>
              </label>
              
              <label className="flex items-center gap-3 p-3 rounded-lg hover:bg-white/30 transition-colors">
                <input
                  type="checkbox"
                  className="rounded text-purple-600 focus:ring-purple-300"
                />
                <div>
                  <span className="text-sm text-gray-700 font-medium">Export Reflection Summary</span>
                  <p className="text-xs text-gray-500">Save your exploration for offline reflection</p>
                </div>
              </label>
            </div>
          </div>
        </div>

        <div className="mt-8 flex justify-end">
          <button 
            onClick={onClose}
            className="px-6 py-2 bg-[#8E7BEF] text-white rounded-full hover:bg-purple-600 transition-colors shadow-md"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
