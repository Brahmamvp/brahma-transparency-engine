import React from 'react';

export default function ActionButtons({ onViewChange, currentView }) {
  const buttons = [
    { id: 'network', label: '🌐 Network View', icon: '🌐' },
    { id: 'clusters', label: '🔗 Clusters', icon: '🔗' },
    { id: 'year', label: '📅 Year View', icon: '📅' },
    { id: 'analysis', label: '🤖 AI Analysis', icon: '🤖' },
    { id: 'export', label: '📤 Export', icon: '📤' },
    { id: 'layers', label: '👁️ Show Layers', icon: '👁️' }
  ];

  return (
    <div className="flex flex-wrap gap-3 mb-6">
      {buttons.map(button => (
        <button
          key={button.id}
          onClick={() => onViewChange(button.id)}
          className={`px-4 py-2 rounded-full text-sm font-medium transition-all glassmorphism hover:glassmorphism-strong ${
            currentView === button.id ? 'button-glow' : ''
          } text-white/90 hover:text-white`}
        >
          <span className="mr-2">{button.icon}</span>
          {button.label.replace(/^.+ /, '')}
        </button>
      ))}
    </div>
  );
}
