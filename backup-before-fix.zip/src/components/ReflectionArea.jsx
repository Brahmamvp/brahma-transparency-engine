
import React, { useState, useEffect } from 'react';
import ReflectionCard from './ReflectionCard';
import JournalModal from './JournalModal';
import ArchivePanel from './ArchivePanel';
import { useSage } from '../context/SageContext';
import { useUserPreferences } from '../context/UserPreferencesContext';

export default function ReflectionArea({ 
  options, 
  onAskSage, 
  onRateOption, 
  onExportOptionToSilhouette 
}) {
  const [pinnedOptions, setPinnedOptions] = useState(new Set());
  const [hiddenOptions, setHiddenOptions] = useState(new Set());
  const [archivedOptions, setArchivedOptions] = useState([]);
  const [showReflectionPrompt, setShowReflectionPrompt] = useState(false);
  const [journalModalOpen, setJournalModalOpen] = useState(false);
  const [archivePanelOpen, setArchivePanelOpen] = useState(false);
  const [reflectionEntries, setReflectionEntries] = useState([]);

  const { state, dispatch } = useSage();
  const { assumptions } = useUserPreferences();

  // Trigger reflection prompt after exploring 3+ cards
  useEffect(() => {
    if (options.length >= 3 && !showReflectionPrompt) {
      setTimeout(() => setShowReflectionPrompt(true), 2000);
    }
  }, [options.length, showReflectionPrompt]);

  const handlePin = (id) => {
    const newPinned = new Set(pinnedOptions);
    if (newPinned.has(id)) {
      newPinned.delete(id);
    } else {
      newPinned.add(id);
    }
    setPinnedOptions(newPinned);
  };

  const handleHide = (id) => {
    const newHidden = new Set(hiddenOptions);
    newHidden.add(id);
    setHiddenOptions(newHidden);
    
    // Move to archive
    const optionToArchive = options.find(opt => opt.id === id);
    if (optionToArchive) {
      setArchivedOptions(prev => [...prev, optionToArchive]);
    }
  };

  const handleRestoreOption = (option) => {
    setHiddenOptions(prev => {
      const newHidden = new Set(prev);
      newHidden.delete(option.id);
      return newHidden;
    });
    setArchivedOptions(prev => prev.filter(opt => opt.id !== option.id));
  };

  const handleJournalEntry = (entry) => {
    setReflectionEntries(prev => [...prev, entry]);
  };

  const handleAskSageFromCard = (option) => {
    dispatch({ type: 'SET_ACTIVE_CARD', payload: option });
    onAskSage(option);
  };

  const visibleOptions = options.filter(option => !hiddenOptions.has(option.id));
  const pinnedFirst = visibleOptions.sort((a, b) => {
    if (pinnedOptions.has(a.id) && !pinnedOptions.has(b.id)) return -1;
    if (!pinnedOptions.has(a.id) && pinnedOptions.has(b.id)) return 1;
    return 0;
  });

  return (
    <div className="space-y-6">
      {options.length === 0 ? (
        <div className="glassmorphism p-8 rounded-xl text-center">
          <div className="text-4xl mb-4">🌱</div>
          <p className="text-gray-600 font-light">Your reflection space</p>
          <p className="text-sm text-gray-500 mt-2">As you chat with Sage, possibilities will appear here for you to explore.</p>
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-medium text-gray-700">Possibilities to Explore</h2>
            <div className="flex items-center gap-3">
              <span className="text-xs text-gray-500">{visibleOptions.length} showing</span>
              {pinnedOptions.size > 0 && (
                <span className="text-xs text-purple-600 bg-purple-100 px-2 py-1 rounded-full">
                  {pinnedOptions.size} pinned
                </span>
              )}
              {archivedOptions.length > 0 && (
                <button
                  onClick={() => setArchivePanelOpen(true)}
                  className="text-xs text-gray-500 hover:text-gray-700 bg-gray-100 px-2 py-1 rounded-full transition-colors"
                >
                  🗃️ {archivedOptions.length} archived
                </button>
              )}
            </div>
          </div>
          
          <div className="space-y-4">
            {pinnedFirst.map(option => (
              <ReflectionCard 
                key={option.id}
                option={option}
                onPin={handlePin}
                onHide={handleHide}
                onAskSage={handleAskSageFromCard}
                isPinned={pinnedOptions.has(option.id)}
                isHidden={hiddenOptions.has(option.id)}
                assumptions={assumptions}
                onRate={onRateOption}
                onExportToSilhouette={onExportOptionToSilhouette}
              />
            ))}
          </div>

          {/* Reflection Loop Prompt */}
          {showReflectionPrompt && (
            <div className="glassmorphism p-6 rounded-xl border-2 border-purple-200 slide-in">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-6 h-6 rounded-full bg-gradient-to-r from-purple-400 to-teal-400 flex items-center justify-center text-white text-xs font-medium">S</div>
                <span className="text-sm font-medium text-gray-700">Reflection Moment</span>
              </div>
              <p className="text-sm text-gray-700 font-light mb-4">
                You've been exploring several possibilities. Want to reflect on what stands out to you?
              </p>
              <div className="flex gap-2">
                <button 
                  onClick={() => {
                    setJournalModalOpen(true);
                    setShowReflectionPrompt(false);
                  }}
                  className="text-sm px-4 py-2 bg-gradient-to-r from-purple-500 to-teal-500 text-white rounded-full hover:shadow-lg transition-shadow"
                >
                  Open Journal
                </button>
                <button 
                  onClick={() => {
                    onAskSage({ title: 'reflection on all options', type: 'reflection' });
                    setShowReflectionPrompt(false);
                  }}
                  className="text-sm px-4 py-2 border border-purple-300 text-purple-700 rounded-full hover:bg-purple-50 transition-colors"
                >
                  Talk with Sage
                </button>
              </div>
            </div>
          )}

          {/* Reflection Entries Display */}
          {reflectionEntries.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-sm font-medium text-gray-600">Your Reflections</h3>
              {reflectionEntries.slice(-2).map((entry, idx) => (
                <div key={idx} className="bg-white/50 p-4 rounded-lg border-l-4 border-teal-300">
                  <p className="text-xs text-gray-500 mb-1">{entry.prompt}</p>
                  <p className="text-sm text-gray-700">{entry.content}</p>
                  <p className="text-xs text-gray-400 mt-2">
                    {new Date(entry.timestamp).toLocaleDateString()}
                  </p>
                </div>
              ))}
              {reflectionEntries.length > 2 && (
                <button className="text-xs text-gray-500 hover:text-gray-700 underline">
                  View all reflections ({reflectionEntries.length})
                </button>
              )}
            </div>
          )}
        </>
      )}

      <JournalModal 
        isOpen={journalModalOpen}
        onClose={() => setJournalModalOpen(false)}
        onSaveEntry={handleJournalEntry}
      />
      
      <ArchivePanel 
        isOpen={archivePanelOpen}
        onClose={() => setArchivePanelOpen(false)}
        archivedOptions={archivedOptions}
        onRestoreOption={handleRestoreOption}
      />
    </div>
  );
}