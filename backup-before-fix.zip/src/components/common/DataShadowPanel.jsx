import React, { useState } from 'react';

const DataShadowPanel = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState('tracking');
  const dataValue = 47.23;

  const trackingData = [
    { source: 'Browser Fingerprinting', frequency: 'Continuous', value: '$12.40/month', risk: 'High' },
    { source: 'Location History', frequency: 'Every 15 min', value: '$8.90/month', risk: 'Medium' },
    { source: 'Search Patterns', frequency: 'Per query', value: '$15.20/month', risk: 'High' },
    { source: 'Device Analytics', frequency: 'Real-time', value: '$6.80/month', risk: 'Low' },
    { source: 'Social Graph', frequency: 'Daily sync', value: '$3.93/month', risk: 'Medium' }
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 max-w-4xl w-full max-h-[90vh] overflow-hidden border border-white/20 shadow-2xl">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">Data Shadow Panel</h2>
            <p className="text-gray-300 text-sm">See what's being collected about you</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors text-xl">✕</button>
        </div>

        <div className="flex space-x-1 mb-6 bg-white/10 rounded-xl p-1">
          {['tracking', 'value', 'protection'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-all ${
                activeTab === tab ? 'bg-purple-600/50 text-white' : 'text-gray-300 hover:text-white hover:bg-white/10'
              }`}
            >
              {tab === 'tracking' ? 'Passive Tracking' : tab === 'value' ? 'Data Value' : 'Protection Status'}
            </button>
          ))}
        </div>

        <div className="overflow-y-auto max-h-96">
          {activeTab === 'tracking' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold text-white">Active Data Collection</h3>
                <div className="text-xs text-red-400">⚠️ {trackingData.length} sources detected</div>
              </div>
              <div className="space-y-3">
                {trackingData.map((item, index) => (
                  <div key={index} className="bg-white/5 rounded-xl p-4 border border-white/10">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-medium text-white">{item.source}</h4>
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        item.risk === 'High' ? 'bg-red-500/20 text-red-400' :
                        item.risk === 'Medium' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-green-500/20 text-green-400'
                      }`}>
                        {item.risk} Risk
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Frequency: {item.frequency}</span>
                      <span className="text-emerald-400 font-medium">{item.value}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'value' && (
            <div className="space-y-6">
              <div className="text-center">
                <div className="text-4xl font-bold text-white mb-2">${dataValue.toFixed(2)}</div>
                <p className="text-gray-300 text-sm mb-4">Estimated monthly value of your data</p>
                <div className="bg-white/10 rounded-xl p-4">
                  <p className="text-xs text-gray-400 mb-3">Based on industry averages:</p>
                  <div className="grid grid-cols-2 gap-4 text-xs">
                    <div><span className="text-gray-300">Search data:</span><span className="text-emerald-400 ml-2">$15.20</span></div>
                    <div><span className="text-gray-300">Location data:</span><span className="text-emerald-400 ml-2">$8.90</span></div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'protection' && (
            <div className="space-y-4">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-emerald-500 to-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">🛡️</span>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Local-Only Protection Active</h3>
                <p className="text-gray-300 text-sm">Your data remains on your device</p>
              </div>
            </div>
          )}
        </div>

        <div className="mt-6 pt-4 border-t border-white/10">
          <div className="flex justify-between items-center">
            <div className="text-xs text-gray-400">Last updated: {new Date().toLocaleTimeString()}</div>
            <button onClick={onClose} className="bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded-lg text-white text-sm font-medium transition-colors">Close</button>
          </div>
        </div>
      </div>
    </div>
  );
};
export default DataShadowPanel;
