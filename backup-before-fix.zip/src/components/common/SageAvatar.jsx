import React from "react";

/**
 * Minimal animated avatar.
 * Props:
 *  - form: "orb" | "geo" | "silhouette" (visual hint)
 *  - emotion: "calm" | "thinking" | "excited" | "focused"
 *  - size: "small" | "md" | "lg"
 */
export default function SageAvatar({
  form = "orb",
  emotion = "calm",
  size = "md",
}) {
  const sz =
    size === "small" ? "w-8 h-8" : size === "lg" ? "w-20 h-20" : "w-12 h-12";

  const colorByEmotion = {
    calm: "from-indigo-400 to-purple-400",
    thinking: "from-blue-400 to-cyan-400",
    excited: "from-pink-400 to-rose-400",
    focused: "from-emerald-400 to-teal-400",
  }[emotion] || "from-indigo-400 to-purple-400";

  const shape =
    form === "geo"
      ? "rounded-md"
      : form === "silhouette"
      ? "rounded-[36%]"
      : "rounded-full";

  return (
    <div
      className={`sage-avatar ${sz} bg-gradient-to-br ${colorByEmotion} ${shape} shadow-glow relative overflow-hidden`}
      title={`Sage • ${emotion}`}
    >
      {/* subtle inner glints */}
      <div className="absolute inset-0 opacity-30 mix-blend-screen pointer-events-none animate-glow-pulse">
        <div className="absolute -top-2 -left-2 w-1/2 h-1/2 bg-white/25 blur-2xl" />
        <div className="absolute -bottom-2 -right-2 w-1/2 h-1/2 bg-white/20 blur-2xl" />
      </div>
    </div>
  );
}