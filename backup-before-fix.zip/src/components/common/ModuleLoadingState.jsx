import React from "react";

const ModuleLoadingState = ({ isLoading, moduleName, children }) => {
  if (isLoading) {
    return (
      <div className="bg-white/10 backdrop-blur-md rounded-xl p-8 border border-white/20 min-h-[400px] flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="relative">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center mx-auto animate-pulse">
              🧠
            </div>
            <div className="absolute inset-0 rounded-full border-4 border-purple-400/30 animate-spin"></div>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white mb-2">Loading {moduleName}</h3>
            <p className="text-gray-300 text-sm">Preparing your intelligent workspace...</p>
          </div>
        </div>
      </div>
    );
  }
  return children;
};

export default ModuleLoadingState;