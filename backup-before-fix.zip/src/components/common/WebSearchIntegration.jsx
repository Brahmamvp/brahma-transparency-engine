import React, { useState } from "react";
import { Globe } from "lucide-react";

const WebSearchIntegration = ({ onSearchResults }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);

  const performWebSearch = async (query) => {
    if (!query?.trim()) return;
    setIsSearching(true);
    try {
      // Replace with your real search service
      const res = await fetch("/api/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query }),
      });
      const results = await res.json();
      setSearchResults(results || []);
      onSearchResults?.(results || []);
    } catch (err) {
      console.error("Search failed:", err);
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="bg-white/10 backdrop-blur-md rounded-xl p-4 border border-white/20">
      <h3 className="text-lg font-semibold mb-3 flex items-center gap-2 text-white">
        <Globe className="w-5 h-5 text-emerald-400" />
        Real-Time Information
      </h3>

      <div className="flex gap-3">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search current events, market data, latest news…"
          className="flex-1 bg-white/10 text-white placeholder-gray-400 px-4 py-3 rounded-xl border border-white/20 focus:ring-2 focus:ring-emerald-500"
        />
        <button
          onClick={() => performWebSearch(searchQuery)}
          disabled={!searchQuery.trim() || isSearching}
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-3 rounded-xl"
        >
          {isSearching ? "Searching…" : "Search"}
        </button>
      </div>

      {!!searchResults.length && (
        <div className="mt-4 space-y-3">
          {searchResults.map((r, i) => (
            <div key={i} className="bg-white/5 rounded-lg p-4">
              <h5 className="font-medium text-white">{r.title}</h5>
              <p className="text-gray-300 text-sm">{r.snippet}</p>
              <span className="text-xs text-emerald-400">{r.source}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default WebSearchIntegration;